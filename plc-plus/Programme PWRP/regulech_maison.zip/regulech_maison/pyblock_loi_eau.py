# ============================================================
# pyblock  : loi_eau  (Plancher Chauffant)
# Projet   : Régulation maison solaire + chaudière
# Auteur   : regulech — transposition Proview 25-NOV-2023
# Remplace : CArit75, CArit232, Mux77, Timer11/12/21/22,
#            Wait×6, XOr3/8/9, Inv30/31, SR_R13/14, K7K8/K9
#
# Ports d'ENTRÉE (câbler dans RPI-PLC Studio) :
#   A1 = T_exterieur         (ANA1 + CTN_2)
#   A2 = T_ambiance          (ANA0 + CTN_1)
#   A3 = T_depart            (ANA6 + CTN_7 — départ chauffage)
#   A4 = T_consigne_ambiance (AV.Conssigne_Ambiance)
#   A5 = correction_jn       (AV.Correction_Jour_Nuit)
#   A6 = correction_depart_sol(AV.Corection_Depart_V3V_Solaire)
#   A7 = T_depart_max        (AV.Conssigne_Depart_V3V_Max)
#   A8 = T_degommage         (AV.Cons_temp_de_marche_Degommage)
#   d1 = v3v_solaire_pos     (← RF1 de solaire_thermique)
#   d2 = marche_chauffage    (DV_tor-BP_Marche_Arret_Chauffage)
#   d3 = marche_sol          (DV_tor-BP_Marche_Cauffage_Solaire)
#   d4 = periode_confort     (← bloc Jours od1)
#   d5 = forcage_circ        (DV_tor-BP_Forcage_Circulateur_Planché)
#   d6 = forcage_close       (DV_tor-BP_Forcage_v3v_close)
#   d7 = forcage_open        (DV_tor-BP_Forcage_v3v_open)
#   d8 = arret_v3v           (DV_tor-BP_Arret_V3V)
#
# Ports de SORTIE :
#   OA1 = consigne_depart_chaudiere (loi d'eau brute → chaudiere)
#   OA2 = consigne_depart_solaire   (OA1 + correction sol)
#   OA3 = consigne_ambiance_corr    (Tj/N corrigé — affichage)
#   od1 = circ_plancher_on          → K9_Circulateur_Planche (GPIO6)
#   od2 = v3v_inc                   → K7_K8 BaseDirValve.oinc (GPIO17)
#   od3 = v3v_dec                   → K7_K8 BaseDirValve.odec (GPIO4)
#   od4 = demande_chaudiere_plancher→ pyblock chaudiere.d3
#   od5 = surchauffe_depart         (info — départ > consigne)
# ============================================================

import math

T_ext        = A1
T_amb        = A2
T_dep        = A3
T_cons_amb   = A4
corr_jn      = A5
corr_dep_sol = A6
T_dep_max    = A7
T_degom      = A8

v3v_sol_pos  = d1
marche_ch    = d2
marche_sol   = d3
confort      = d4
forcage_circ = d5
forcage_close= d6
forcage_open = d7
arret_v3v    = d8

# ── State ──────────────────────────────────────────────────
if "sr13"  not in state: state["sr13"]  = False  # SR_R13 circ plancher sol
if "sr14"  not in state: state["sr14"]  = False  # SR_R14 circ plancher ch
if "t11"   not in state: state["t11"]   = 0.0    # Timer11 (4s) dépl. V3V
if "t12"   not in state: state["t12"]   = 0.0    # Timer12 (4s) retour
if "t21"   not in state: state["t21"]   = 0.0    # Timer21 (15s) période
if "t22"   not in state: state["t22"]   = 0.0    # Timer22 (15s)
if "t7"    not in state: state["t7"]    = 0.0    # Timer7  (1800s anti-gom)
if "v3v_p" not in state: state["v3v_p"] = 0      # position V3V (-1,0,+1)

# ── CArit75 — Loi d'eau ────────────────────────────────────
# OA1 = 0.6*(Tc - Text) + Tc   (loi d'eau linéaire)
OA1 = 0.6 * (T_cons_amb - T_ext) + T_cons_amb
OA1 = min(OA1, T_dep_max)       # sécurité départ max

# OA2 = consigne solaire (+ correction si V3V en position sol)
OA2 = OA1 + corr_dep_sol if v3v_sol_pos else OA1

# OA3 = consigne ambiance corrigée Jour/Nuit
OA3 = T_cons_amb + corr_jn if confort else T_cons_amb

# Demande de chauffe (ambiance)
demande_chauff = T_amb < OA3

# ── od6 : circulateur plancher chaudière (si !sol) ─────────
od6_circ_ch = (not v3v_sol_pos) and marche_ch and demande_chauff

# ── od1 : circulateur plancher solaire ─────────────────────
od1_circ_sol = v3v_sol_pos and (not od5_sur if "od5_sur" in dir() else True) \
               and marche_sol and marche_ch and demande_chauff

# Circulateur plancher : OR des deux conditions + forçage
od1 = od6_circ_ch or od1_circ_sol or forcage_circ

# ── Surchauffe départ V3V ──────────────────────────────────
consigne_active = OA2 if v3v_sol_pos else OA1
od5 = T_dep > (consigne_active + 0.5)    # d2 de CArit75

# ── CArit232 — Régulation V3V départ (Mux77 + Inv30/31) ───
# Période de régulation : Timer21/22 = 15s
state["t21"] += dt
if state["t21"] >= 15.0:
    state["t21"] = 0.0
    # Impulsion de commande V3V
    if T_dep < (consigne_active - 0.5):
        state["v3v_p"] = 1   # od1 CArit232 → inc
    elif T_dep > (consigne_active + 0.5):
        state["v3v_p"] = -1  # od2 CArit232 → dec
    else:
        state["v3v_p"] = 0

# Durée de l'impulsion : Timer11/12 = 4s
if state["v3v_p"] != 0:
    state["t11"] += dt
    if state["t11"] >= 4.0:
        state["v3v_p"] = 0
        state["t11"] = 0.0
else:
    state["t11"] = 0.0

# Forçages XOr8/9
if not arret_v3v:
    od2 = (state["v3v_p"] == 1)  or forcage_open    # inc
    od3 = (state["v3v_p"] == -1) or forcage_close   # dec
else:
    od2 = False; od3 = False

# ── Anti-gommage Timer7 = 1800s ────────────────────────────
state["t7"] += dt
if state["t7"] >= 1800.0:
    od1 = True   # force circulateur pendant 1 cycle
    state["t7"] = 0.0

# ── Demande chaudière plancher ─────────────────────────────
od4 = demande_chauff and marche_ch and (not v3v_sol_pos)

# ── Écriture registres partagés ────────────────────────────
write_register("RF5",  OA1)           # consigne départ → chaudiere
write_register("RF6",  float(od1))    # circ plancher → ecs.circ_plancher
write_register("RF7",  float(od4))    # demande plancher → chaudiere
write_register("RF8",  float(od5))    # surchauffe → loi_eau info
