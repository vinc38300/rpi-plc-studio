# Régulation maison — Intégration RPI-PLC Studio
**Transposition : Proview 25-NOV-2023 → RPI-PLC Studio**
Auteur : regulech | Avril 2026

---

## Fichiers livrés

| Fichier | Rôle |
|---|---|
| `regulech_maison.json` | Projet complet RPI-PLC Studio (ouvrir via Fichier → Ouvrir) |
| `pyblock_jours.py` | Planning 7 jours Jour/Nuit |
| `pyblock_solaire_thermique.py` | Commutation V3V solaire + compteur |
| `pyblock_gestion_ecs.py` | Ballon ECS double énergie |
| `pyblock_loi_eau.py` | Loi d'eau + régulation V3V plancher |
| `pyblock_chaudiere.py` | Autorisation chaudière + réhausse |

---

## Registres RF partagés entre blocs

```
RF0  = ΔT capteurs-retour        (solaire → synoptique)
RF1  = v3v_solaire_on  bool       (solaire → loi_eau.d1, chaudiere.d8)
RF2  = demande_ecs     bool       (gestion_ecs → chaudiere.d1)
RF3  = demande_mini    bool       (gestion_ecs → chaudiere.d2)
RF5  = consigne_depart float °C   (loi_eau → chaudiere.a4)
RF6  = circ_plancher   bool       (loi_eau → ecs.d4, chaudiere.d6)
RF7  = demande_plancher bool      (loi_eau → chaudiere.d3)
RF9  = autorisation_ch bool       (→ synoptique)
RF13 = correction_jn   float °C   (→ synoptique)
RF14 = heure_courante  int        (LocalTime → jours.a1)
RF15 = jour_semaine    int        (LocalTime → jours.i1)
```

## Ordre d'exécution PLC recommandé

1. Lecture LocalTime → RF14/RF15
2. **bloc_jours** → M0_periode_confort
3. **solaire_thermique** → RF1, GPIO11, GPIO13
4. **loi_eau** → RF5, RF6, RF7, GPIO6, GPIO17, GPIO4
5. **gestion_ecs** → RF2, RF3, GPIO22, GPIO27
6. **chaudiere** → GPIO5, GPIO10

## Valeurs AV par défaut (modifiables depuis le synoptique)

| Paramètre | Valeur | Unité |
|---|---|---|
| Conssigne_Ambiance | 19 | °C |
| Correction_Jour_Nuit | 2 | °C |
| Conssigne_Ballons | 55 | °C |
| Conssigne_Ballons_Max | 85 | °C |
| Secu_Panneaux_Solaire_Max | 95 | °C |
| Conssigne_Panneaux_Solaire_Mini | 35 | °C |
| Hyst_Ballon_Bas | 3 | °C |
| Hyst_Ballon_Haut | 5 | °C |
| Hyst_RetourFroid_Solaire | 5 | °C |
| Horaires L-V début/fin | 7h / 22h | h |
| Horaires S-D début/fin | 8h / 23h | h |
| Tous Corection_CTN_x | 0 | °C (à calibrer) |
