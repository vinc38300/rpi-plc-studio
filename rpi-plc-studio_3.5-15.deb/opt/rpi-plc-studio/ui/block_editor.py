"""
ui/block_editor.py — Éditeur FBD (Function Block Diagram) style Proview/IEC 61131-3
Utilise QWebEngineView + canvas HTML5 pour le dessin interactif.
"""

import os
import json
import re
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt5.QtCore    import Qt, pyqtSignal, QUrl, QObject, pyqtSlot
from PyQt5.QtGui     import QFont

try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEngineScript, QWebEnginePage

    class _DebugPage(QWebEnginePage):
        def javaScriptConsoleMessage(self, level, message, line, source):
            prefix = ['DBG','INF','WRN','ERR'][min(level,3)]
            print(f"fbd[{prefix}] {source}:{line} — {message}")
    from PyQt5.QtWebChannel       import QWebChannel
    HAS_WEBENGINE = True
except ImportError:
    HAS_WEBENGINE = False


class PyBridge(QObject):
    """Pont JS → Python exposé via QWebChannel sous le nom 'pybridge'."""
    diagram_changed  = pyqtSignal(str)
    analog_sim_set   = pyqtSignal(str, float)   # (ref, value en V)
    analog_sim_celsius = pyqtSignal(str, float) # (ref, value en °C direct)
    open_doc_requested  = pyqtSignal()              # demande d'ouverture doc

    @pyqtSlot(str)
    def on_diagram_changed(self, json_str: str):
        self.diagram_changed.emit(json_str)

    @pyqtSlot(str, float)
    def set_analog_sim(self, ref: str, value: float):
        """Appelé depuis le curseur de simulation dans le canvas."""
        self.analog_sim_set.emit(ref, value)

    @pyqtSlot(str, float)
    def set_analog_celsius(self, ref: str, celsius: float):
        self.analog_sim_celsius.emit(ref, celsius)

    @pyqtSlot(str)
    def open_doc(self, _section: str = ''):
        """Ouvre la documentation depuis un canvas HTML (F1)."""
        self.open_doc_requested.emit()

    def set_pending_diagram(self, json_str: str):
        """Stocke un diagramme JSON en attente de récupération par get_pending_diagram."""
        self._pending_diagram = json_str

    @pyqtSlot(result=str)
    def get_pending_diagram(self) -> str:
        """Retourne le diagramme JSON en attente (appelé depuis JS via QWebChannel)."""
        d = getattr(self, '_pending_diagram', None) or '{}'
        self._pending_diagram = None
        return d

    def set_pending_state(self, json_str: str):
        """Stocke un état PLC en attente."""
        self._pending_state = json_str

    @pyqtSlot(result=str)
    def get_pending_state(self) -> str:
        """Retourne l'état PLC en attente."""
        s = getattr(self, '_pending_state', None) or '{}'
        self._pending_state = None
        return s

    @pyqtSlot(str, result=str)
    def check_pyblock_syntax(self, code: str) -> str:
        """Vérifie la syntaxe Python + analyse statique basique du code PYBLOCK.
        Retourne un JSON : {"ok": true} ou {"ok": false, "line": N, "msg": "..."}
        """
        import json, ast, tokenize, io
        if not code.strip():
            return json.dumps({"ok": True, "warnings": []})
        warnings = []
        # 1. Vérification syntaxe
        try:
            tree = ast.parse(code)
        except SyntaxError as e:
            return json.dumps({
                "ok": False,
                "line": e.lineno or 1,
                "col":  e.offset or 1,
                "msg":  str(e.msg),
                "text": str(e.text or "").strip(),
            })
        # 2. Analyse statique : détecter problèmes courants
        class _Checker(ast.NodeVisitor):
            def __init__(self):
                self.warns = []
            def visit_Import(self, node):
                for alias in node.names:
                    if alias.name not in ('math','datetime','statistics','time'):
                        self.warns.append({
                            "line": node.lineno,
                            "msg": f"import '{alias.name}' non autorisé en PYBLOCK"
                        })
            def visit_ImportFrom(self, node):
                if node.module not in ('math','datetime','statistics','time'):
                    self.warns.append({
                        "line": node.lineno,
                        "msg": f"from {node.module} import non autorisé"
                    })
            def visit_Call(self, node):
                if isinstance(node.func, ast.Name):
                    if node.func.id in ('exec','eval','open','__import__','compile'):
                        self.warns.append({
                            "line": node.lineno,
                            "msg": f"Appel interdit : {node.func.id}()"
                        })
                self.generic_visit(node)
        chk = _Checker()
        chk.visit(tree)
        # 3. Vérif variables PYBLOCK non définies (heuristique)
        known_vars = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.Assign):
                for t in n.targets:
                    if isinstance(t, ast.Name): known_vars.add(t.id)
        return json.dumps({"ok": True, "warnings": chk.warns})

    @pyqtSlot(str, int, int, result=str)
    def run_pyblock_test(self, code: str, n_a: int, n_d: int) -> str:
        """Exécute le code PYBLOCK avec des valeurs test et retourne le résultat.
        Retourne un JSON avec les valeurs de sortie ou l'erreur.
        """
        import json, math, datetime, statistics, traceback
        if not code.strip():
            return json.dumps({"ok": False, "error": "Code vide"})
        # Le moteur fournit toujours A1-A12 et d1-d12 ; le testeur doit en faire autant
        # pour éviter les NameError sur les blocs qui utilisent n_a > 8 ou n_d > 8.
        _na = max(n_a, 12)
        _nd = max(n_d, 12)
        # Valeurs test par défaut
        ctx = {
            **{f"A{i}": float(20 + i * 5) for i in range(1, _na + 1)},
            **{f"d{i}": (i % 2 == 1) for i in range(1, _nd + 1)},
            **{f"I{i}": i * 10 for i in range(1, 3)},
            **{f"OA{i}": 0.0 for i in range(1, _na + 1)},
            **{f"od{i}": False for i in range(1, _nd + 1)},
            "OI1": 0,
            "dt": 0.1, "cycle": 1,
            "state": {},
            "read_analog":    lambda ref: 25.0,
            "read_signal":    lambda ref: False,
            "write_register": lambda ref, v: None,
            "write_signal":   lambda ref, v: None,
            "math": math, "datetime": datetime, "statistics": statistics,
            "abs": abs, "min": min, "max": max, "round": round,
            "int": int, "float": float, "bool": bool, "str": str,
            "len": len, "range": range, "list": list, "dict": dict,
            "sum": sum, "sorted": sorted, "any": any, "all": all,
            "print": print,
        }
        output_lines = []
        import io, sys
        old_stdout = sys.stdout
        sys.stdout = buf = io.StringIO()
        try:
            exec(compile(code, "<test>", "exec"), {"__builtins__": {}}, ctx)
            sys.stdout = old_stdout
            output_lines = buf.getvalue().strip().splitlines()
        except Exception as e:
            sys.stdout = old_stdout
            tb = traceback.extract_tb(e.__traceback__)
            line = tb[-1].lineno if tb else 1
            return json.dumps({
                "ok": False,
                "line": line,
                "error": f"{type(e).__name__}: {e}",
                "print": buf.getvalue().strip().splitlines(),
            })
        outputs = {}
        for i in range(1, _na + 1):
            v = ctx.get(f"OA{i}", 0.0)
            if v != 0.0: outputs[f"OA{i}"] = round(float(v), 4)
        for i in range(1, _nd + 1):
            v = ctx.get(f"od{i}", False)
            if v: outputs[f"od{i}"] = bool(v)
        if ctx.get("OI1", 0) != 0: outputs["OI1"] = int(ctx["OI1"])
        return json.dumps({
            "ok": True,
            "outputs": outputs,
            "state": {k: str(v)[:80] for k, v in ctx["state"].items()},
            "print": output_lines,
        })

    @pyqtSlot(str)
    def save_group_library(self, json_str: str):
        """Sauvegarde la bibliothèque de groupes dans un fichier JSON."""
        import os, json
        lib_dir = os.path.join(os.path.expanduser('~'), '.rpi-plc-studio')
        os.makedirs(lib_dir, exist_ok=True)
        lib_path = os.path.join(lib_dir, 'group_library.json')
        try:
            with open(lib_path, 'w', encoding='utf-8') as f:
                f.write(json_str)
        except Exception as e:
            print(f"[Library] Erreur sauvegarde: {e}")

    @pyqtSlot(result=str)
    def load_group_library(self) -> str:
        """Charge la bibliothèque de groupes. Retourne le JSON (max 60KB)
        ou un chemin /tmp si le JSON est trop grand pour QWebChannel."""
        import os, json, tempfile, shutil
        lib_path = os.path.join(os.path.expanduser('~'), '.rpi-plc-studio', 'group_library.json')
        try:
            if os.path.exists(lib_path):
                with open(lib_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                # QWebChannel limite les retours à ~64KB
                # Si la bibliothèque est trop grande, passer par un fichier /tmp
                if len(content) < 60000:
                    return content
                else:
                    # Copier dans /tmp et retourner un marqueur spécial
                    tmp_lib = os.path.join(tempfile.gettempdir(), 'rpi_plc_group_lib.json')
                    shutil.copy(lib_path, tmp_lib)
                    return '__FILE__:' + tmp_lib
        except Exception as e:
            print(f"[Library] Erreur chargement: {e}")
        return '{}'  


class BlockEditor(QWidget):
    """
    Éditeur FBD embarqué via QWebEngineView.
    Émet program_changed(list) à chaque modification.
    """
    program_changed = pyqtSignal(list)
    diagram_changed = pyqtSignal(dict)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._diagram = {"blocks": [], "wires": []}
        self._build_ui()

    def _build_ui(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)

        if not HAS_WEBENGINE:
            lbl = QLabel(
                "QtWebEngine non disponible.\n\n"
                "Installer avec :\n"
                "  sudo apt install python3-pyqt5.qtwebengine\n"
                "  pip3 install PyQtWebEngine"
            )
            lbl.setAlignment(Qt.AlignCenter)
            lbl.setStyleSheet("color:#f85149;font-size:13px;padding:40px;")
            lay.addWidget(lbl)
            return

        self.view   = QWebEngineView()
        # Forcer une taille minimale pour que QtWebEngine alloue le viewport
        self.view.setMinimumSize(200, 200)
        from PyQt5.QtWidgets import QSizePolicy
        self.view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        if HAS_WEBENGINE:
            self._debug_page = _DebugPage()
            self.view.setPage(self._debug_page)
        # Activer localStorage pour la bibliothèque de groupes
        try:
            from PyQt5.QtWebEngineWidgets import QWebEngineSettings
            settings = self.view.page().settings()
            settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
            settings.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
            # Définir un dossier persistant pour le profil
            profile = self.view.page().profile()
            import os
            lib_dir = os.path.join(os.path.expanduser('~'), '.rpi-plc-studio')
            os.makedirs(lib_dir, exist_ok=True)
            profile.setPersistentStoragePath(lib_dir)
            profile.setPersistentCookiesPolicy(profile.AllowPersistentCookies)
        except Exception as _e:
            pass
        self.bridge = PyBridge()
        self.channel = QWebChannel()
        self.channel.registerObject("pybridge", self.bridge)
        self.view.page().setWebChannel(self.channel)

        # Injecter le script qui initialise QWebChannel côté JS
        init_js = QWebEngineScript()
        init_js.setSourceCode("""
            (function() {
                function _injectQWC() {
                    var s = document.createElement('script');
                    s.src = 'qrc:///qtwebchannel/qwebchannel.js';
                    s.onload = function() {
                        new QWebChannel(qt.webChannelTransport, function(ch) {
                            window.pybridge = ch.objects.pybridge;
                        });
                    };
                    (document.head || document.documentElement).appendChild(s);
                }
                if (document.readyState === 'loading') {
                    document.addEventListener('DOMContentLoaded', _injectQWC);
                } else {
                    _injectQWC();
                }
            })();
        """)
        init_js.setInjectionPoint(QWebEngineScript.DocumentReady)
        init_js.setWorldId(QWebEngineScript.MainWorld)
        self.view.page().scripts().insert(init_js)

        html_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fbd_canvas.html")
        try:
            _size = os.path.getsize(html_path)
            print(f"[FBD] Chargement canvas: {html_path} ({_size} octets)")
        except Exception:
            pass
        # Charger via setHtml() avec base_url pour éviter les problèmes de chemin
        # (espaces, partages réseau, Nextcloud, etc.)
        # Copier dans /tmp pour éviter les problèmes de chemin avec espaces/Nextcloud
        # Inliner le JS dans le HTML et sauver dans /tmp (évite pb CORS fichiers locaux)
        import tempfile
        try:
            _ui_dir   = os.path.dirname(os.path.abspath(html_path))
            _js_path  = os.path.join(_ui_dir, 'fbd_canvas.js')
            with open(html_path, 'r', encoding='utf-8') as _f:
                _html = _f.read()
            if os.path.exists(_js_path):
                with open(_js_path, 'r', encoding='utf-8') as _f:
                    _js = _f.read()
                # Pré-charger la bibliothèque de groupes directement dans le HTML
                # (évite la limite de taille de QWebChannel)
                _lib_path = os.path.join(os.path.expanduser('~'), '.rpi-plc-studio', 'group_library.json')
                _lib_json = '{}'
                try:
                    if os.path.exists(_lib_path):
                        with open(_lib_path, 'r', encoding='utf-8') as _lf:
                            _lib_json = _lf.read().strip() or '{}'
                except Exception:
                    pass
                # Injecter la bibliothèque AVANT le JS principal
                _preload = (f'<script>window._preloadedGroupLib={_lib_json};</script>\n')
                # Remplacer <script src="fbd_canvas.js"> par le JS inline
                _script_tag = '<script>' + chr(10) + _js + chr(10) + '</script>'
                _html = _html.replace('<script src="fbd_canvas.js"></script>',
                                      _preload + _script_tag)
            _tmp_dir  = tempfile.mkdtemp(prefix='rpi_plc_fbd_')
            _tmp_html = os.path.join(_tmp_dir, 'fbd_canvas.html')
            with open(_tmp_html, 'w', encoding='utf-8') as _f:
                _f.write(_html)
            print(f"[FBD] load() HTML inline depuis tmp: {_tmp_html} ({len(_html)} chars)")
            self.view.load(QUrl.fromLocalFile(_tmp_html))
        except Exception as _e:
            print(f"[FBD] Erreur: {_e}")
            self.view.load(QUrl.fromLocalFile(html_path))
        self.bridge.diagram_changed.connect(self._on_js_change)
        self.view.loadFinished.connect(self._on_canvas_loaded)
        self._pending_theme  = None   # thème à appliquer quand le canvas sera prêt
        self._pending_load   = None   # diagramme à charger quand le canvas sera prêt
        self._canvas_ready   = False  # True après loadFinished
        self._pending_analog_config = None  # config sondes à pousser après loadFinished
        lay.addWidget(self.view)

    # ── Thème : appliqué dès que la page est chargée ─────────────────────────
    def _on_canvas_loaded(self, ok: bool):
        """Appelé par loadFinished — appliquer thème et diagramme en attente."""
        from PyQt5.QtCore import QTimer
        self._canvas_ready = True

        # Forcer buildPalette à plusieurs délais (Qt WebEngine timing)
        _bp = "typeof buildPalette==='function' && buildPalette(); typeof buildLibraryPanel==='function' && buildLibraryPanel();"
        self.view.page().runJavaScript(_bp)
        QTimer.singleShot(100,  lambda: self.view.page().runJavaScript(_bp))
        QTimer.singleShot(400,  lambda: self.view.page().runJavaScript(_bp))
        QTimer.singleShot(1000, lambda: self.view.page().runJavaScript(_bp))

        if self._pending_theme:
            name = self._pending_theme
            self._pending_theme = None
            QTimer.singleShot(300, lambda: self.apply_theme(name))
            QTimer.singleShot(500, lambda: self.apply_theme(name))
        if self._pending_load is not None:
            data = self._pending_load
            self._pending_load = None
            QTimer.singleShot(50, lambda: self._do_load(data))
        # Re-pousser la config sondes si elle avait été reçue avant loadFinished
        if self._pending_analog_config is not None:
            _cfg = self._pending_analog_config
            import json as _json
            cfg_js = _json.dumps(_cfg)
            QTimer.singleShot(800, lambda: self.view.page().runJavaScript(
                f"window.setAnalogConfig && window.setAnalogConfig({cfg_js});"
            ))

    def _do_load(self, data):
        """Effectue le chargement réel du diagramme dans le canvas JS."""
        import json as _j
        if isinstance(data, dict) and "pages" in data:
            diagram = data
        elif isinstance(data, dict) and "blocks" in data:
            diagram = {"pages": [{"id":"P1","name":"Page 1",
                                   "blocks": data["blocks"],
                                   "wires":  data["wires"]}], "curPage":0}
        elif isinstance(data, list):
            diagram = self._program_to_fbd(data)
        else:
            return
        self._diagram = diagram
        # Stocker le diagramme dans le bridge, JS l'appelle via callback
        self.bridge.set_pending_diagram(_j.dumps(diagram))
        self.view.page().runJavaScript(
            "if(window.pybridge && window.pybridge.get_pending_diagram){"
            "  window.pybridge.get_pending_diagram(function(d){"
            "    if(d && window.fbdAPI) window.fbdAPI.loadDiagram(JSON.parse(d));"
            "  });"
            "}"
        )
        # Plusieurs passes pour couvrir la latence variable de QtWebEngine
        from PyQt5.QtCore import QTimer
        _js_refresh = ("typeof _initCanvas==='function'&&_initCanvas(); "
                       "typeof resize==='function'&&resize(); "
                       "typeof fitView==='function'&&fitView(); "
                       "typeof render==='function'&&render();")
        QTimer.singleShot(200,  lambda: self.view.page().runJavaScript(_js_refresh))
        QTimer.singleShot(600,  lambda: self.view.page().runJavaScript(_js_refresh))
        QTimer.singleShot(1200, lambda: self.view.page().runJavaScript(_js_refresh))
        QTimer.singleShot(2500, lambda: self.view.page().runJavaScript(
            "typeof resize==='function'&&resize(); "
            "typeof render==='function'&&(pages&&pages.length>0)&&render();"
        ))

    def apply_theme(self, name: str):
        """Applique le thème au canvas FBD (appeler après loadFinished)."""
        js = f"window.setFbdTheme && window.setFbdTheme('{name}');"
        try:
            self.view.page().runJavaScript(js)
        except Exception:
            pass

    # ── Réception depuis JS ───────────────────────────────────────────────────
    def _on_js_change(self, json_str: str):
        try:
            data = json.loads(json_str)
            self._diagram = data
            self.diagram_changed.emit(data)
            prog = self._fbd_to_program(data)
            self.program_changed.emit(prog)
        except Exception as e:
            print(f"[FBD] Erreur : {e}")

    # ── FBD → Programme PLC linéaire ─────────────────────────────────────────
    def _flatten_page(self, page: dict) -> dict:
        """Aplatit récursivement les blocs GROUP d'une page.

        Chaque bloc GROUP encapsule un sous-programme dans params._inner_blocks.
        Cette méthode remplace chaque GROUP par ses blocs internes réels et
        reconnecte les fils qui traversaient la frontière du groupe.
        L'opération est récursive : les groupes imbriqués sont aussi aplatis.

        Returns une nouvelle page dict (sans modifier l'originale).
        """
        import json as _json, copy as _copy, re as _re

        # FIX : les blocs d'un groupe sont numérotés dans le contexte INTERNE du
        # groupe (ids B2, B3... et registres RF100... qui repartent de zéro).
        # Aplatis tels quels, ils entrent en collision avec ceux du programme
        # principal : un bloc interne remplaçait le bloc de même id (ex. AV av0
        # écrasé par le PYBLOCK du groupe) et écrivait dans le registre d'un
        # autre bloc (RF100...). Chaque instance de groupe reçoit donc des ids
        # préfixés et des registres RF neufs, au-dessus de tout RF existant.
        _rf_full = _re.compile(r"RF(\d+)")
        if getattr(self, "_grp_rf_next", None) is None:
            _mx = max([int(n) for n in _re.findall(r"RF(\d+)", _json.dumps(page))] + [99])
            self._grp_rf_next = _mx + 1

        def _renumber(o, idmap, rfmap):
            if isinstance(o, dict):
                return {k: (idmap.get(v, v) if k in ("id", "bid") and isinstance(v, str)
                            else _renumber(v, idmap, rfmap)) for k, v in o.items()}
            if isinstance(o, list):
                return [_renumber(v, idmap, rfmap) for v in o]
            if isinstance(o, str):
                m = _rf_full.fullmatch(o)
                if m and int(m.group(1)) >= 100:      # RF0..RF99 = registres système
                    if o not in rfmap:
                        rfmap[o] = f"RF{self._grp_rf_next}"
                        self._grp_rf_next += 1
                    return rfmap[o]
            return o

        def _flatten_once(page_dict):
            """Un seul passage d'aplatissement — retourne (nouvelle_page, changed)."""
            blocks = list(page_dict.get("blocks", []))
            wires  = list(page_dict.get("wires",  []))
            changed = False

            new_blocks = []
            new_wires  = list(wires)

            for b in blocks:
                if b.get("type") != "GROUP":
                    new_blocks.append(b)
                    continue

                # ── Ce bloc est un GROUP — on l'aplatit ──────────────────
                changed = True
                gid   = b["id"]
                inner_raw = b.get("params", {}).get("_inner_blocks")
                if not inner_raw:
                    # Groupe vide — juste le supprimer
                    new_wires = [w for w in new_wires
                                 if w["src"]["bid"] != gid and w["dst"]["bid"] != gid]
                    continue

                try:
                    saved = _json.loads(inner_raw)
                except Exception:
                    new_blocks.append(b)   # JSON corrompu — garder tel quel
                    continue

                inner_all    = saved.get("blocks", [])
                inner_wires  = saved.get("wires",  [])

                # Blocs réels (sans les ports de groupe)
                real_blocks = [ib for ib in inner_all
                               if ib.get("type") not in ("GROUP_IN", "GROUP_OUT")]

                # Fils internes réels (entre blocs non-GROUP_IN/OUT)
                inner_bid_set = {ib["id"] for ib in inner_all}
                gin_ids  = {ib["id"] for ib in inner_all if ib.get("type") == "GROUP_IN"}
                gout_ids = {ib["id"] for ib in inner_all if ib.get("type") == "GROUP_OUT"}
                real_inner_wires = [
                    iw for iw in inner_wires
                    if iw["src"]["bid"] not in gin_ids
                    and iw["dst"]["bid"] not in gout_ids
                ]

                # Table GROUP_IN : label → {bid, port} destination réelle
                gin_map = {}
                for gin in inner_all:
                    if gin.get("type") != "GROUP_IN":
                        continue
                    label = gin.get("params", {}).get("label") or gin["id"]
                    # fil interne : src=gin.id/SIG → dst=bloc_réel/port
                    for iw in inner_wires:
                        if iw["src"]["bid"] == gin["id"]:
                            gin_map[label] = {"bid": iw["dst"]["bid"],
                                              "port": iw["dst"]["port"]}
                            break

                # Table GROUP_OUT : label → {bid, port} source réelle
                gout_map = {}
                for gout in inner_all:
                    if gout.get("type") != "GROUP_OUT":
                        continue
                    label = gout.get("params", {}).get("label") or gout["id"]
                    # fil interne : src=bloc_réel/port → dst=gout.id/IN
                    for iw in inner_wires:
                        if iw["dst"]["bid"] == gout["id"]:
                            gout_map[label] = {"bid": iw["src"]["bid"],
                                               "port": iw["src"]["port"]}
                            break

                # Ids préfixés + registres RF neufs pour cette instance de groupe
                _idmap = {ib["id"]: f"{gid}_{ib['id']}" for ib in real_blocks}
                _rfmap = {}
                # FIX : un bloc câblé sur la sortie du GROUP (OR, AND, COMPH...) a
                # mémorisé le registre de sortie du GROUP (params.reg_out) comme
                # source. Après aplatissement, le fil est bien repointé vers le bloc
                # interne, mais le paramètre mémorisé ne suit pas : le bloc aval lisait
                # un registre que personne n'écrivait. On fait donc écrire la source
                # interne dans le registre du GROUP lui-même (groupe à sortie unique).
                _grp_ro = (b.get("params") or {}).get("reg_out")
                if isinstance(_grp_ro, str) and _rf_full.fullmatch(_grp_ro) and len(gout_map) == 1:
                    _src_id = list(gout_map.values())[0]["bid"]
                    for _ib in real_blocks:
                        if _ib["id"] == _src_id:
                            _old_ro = (_ib.get("params") or {}).get("reg_out")
                            if isinstance(_old_ro, str) and _rf_full.fullmatch(_old_ro):
                                _rfmap[_old_ro] = _grp_ro
                            break
                real_blocks      = _renumber(real_blocks,      _idmap, _rfmap)
                real_inner_wires = _renumber(real_inner_wires, _idmap, _rfmap)
                gin_map          = _renumber(gin_map,          _idmap, _rfmap)
                gout_map         = _renumber(gout_map,         _idmap, _rfmap)

                # Fils externes pointant vers / depuis ce GROUP
                ext_wires_in  = [w for w in new_wires if w["dst"]["bid"] == gid]
                ext_wires_out = [w for w in new_wires if w["src"]["bid"] == gid]

                # Supprimer les fils externes du GROUP
                new_wires = [w for w in new_wires
                             if w["src"]["bid"] != gid and w["dst"]["bid"] != gid]

                # Reconnecter : fil externe → GROUP.portLabel  →  fil externe → bloc_réel
                for ew in ext_wires_in:
                    port_label = ew["dst"]["port"]
                    inner_dst  = gin_map.get(port_label)
                    if inner_dst:
                        new_wires.append({
                            "id":  "fg_" + ew["id"],
                            "src": _copy.deepcopy(ew["src"]),
                            "dst": _copy.deepcopy(inner_dst),
                        })

                # Reconnecter : GROUP.portLabel → fil externe  →  bloc_réel → fil externe
                for ew in ext_wires_out:
                    port_label = ew["src"]["port"]
                    inner_src  = gout_map.get(port_label)
                    if inner_src:
                        new_wires.append({
                            "id":  "fg_" + ew["id"],
                            "src": _copy.deepcopy(inner_src),
                            "dst": _copy.deepcopy(ew["dst"]),
                        })

                # Ajouter les blocs et fils réels du groupe
                new_blocks.extend(_copy.deepcopy(real_blocks))
                new_wires.extend(_copy.deepcopy(real_inner_wires))

            return {**page_dict, "blocks": new_blocks, "wires": new_wires}, changed

        # Aplatissement récursif jusqu'à ce qu'il n'y ait plus de GROUP
        flat = _copy.deepcopy(page)
        for _ in range(32):   # limite de sécurité pour les imbrications profondes
            flat, changed = _flatten_once(flat)
            if not changed:
                break

        return flat

    def _fbd_to_program(self, diagram: dict) -> list:
        """Convertit toutes les pages du diagramme en un seul programme linéaire.

        IMPORTANT : toutes les pages sont fusionnées en une seule structure avant
        d'appeler _page_to_program.  Cela permet aux paires PAGE_OUT / PAGE_IN
        (signal=SigX) qui se trouvent sur des pages différentes d'être résolues
        en fils virtuels directs — exactement comme si le programme était linéaire
        (à la manière de ProviewR).  Avant ce correctif, chaque page était compilée
        indépendamment et les signaux inter-pages étaient perdus.
        """
        # Compteur RF des groupes : au-dessus de tout RF de TOUTES les pages
        import json as _j, re as _r
        self._grp_rf_next = max([int(n) for n in _r.findall(r"RF(\d+)", _j.dumps(diagram))] + [99]) + 1
        if "pages" in diagram:
            # ── Fusionner tous les blocs + fils de toutes les pages ──────────
            all_blocks: list = []
            all_wires:  list = []
            for pg in diagram["pages"]:
                flat_pg = self._flatten_page(pg)   # aplatit les GROUP
                all_blocks.extend(flat_pg.get("blocks", []))
                all_wires.extend(flat_pg.get("wires",  []))
            merged_page = {"blocks": all_blocks, "wires": all_wires}
            return self._page_to_program(merged_page)
        else:
            # Ancien format mono-page (rétro-compatibilité)
            flat_pg = self._flatten_page(diagram)
            return self._page_to_program(flat_pg)


    def _page_to_program(self, page: dict) -> list:
        """Convertit une page FBD en programme PLC linéaire.
        Gère tous les types de blocs définis dans fbd_canvas.html.
        """
        blocks = {b["id"]: b for b in page.get("blocks", [])}
        wires  = list(page.get("wires", []))

        # ── Résolution des paires PAGE_OUT / PAGE_IN (labels + blocs réels) ──
        # Deux cas :
        #   1) _isLabel:True – créés automatiquement par le canvas (fils longs)
        #   2) Blocs manuels – placés depuis la palette, sans _isLabel
        # Grâce à la fusion des pages dans _fbd_to_program, cette passe
        # résout aussi les paires inter-pages : programme unifié façon ProviewR.
        lbl_out = {}   # signal → id du bloc PAGE_OUT
        lbl_in  = {}   # signal → liste d'ids PAGE_IN (un signal peut être consommé
                       # par plusieurs blocs sur des pages différentes)
        for b in list(blocks.values()):
            if b["type"] not in ("PAGE_OUT", "PAGE_IN"):
                continue
            sig = b.get("params", {}).get("signal", "")
            if not sig:
                continue
            if b["type"] == "PAGE_OUT":
                lbl_out[sig] = b["id"]
            else:
                lbl_in.setdefault(sig, []).append(b["id"])

        virtual_wires = []
        for sig, out_id in lbl_out.items():
            if sig not in lbl_in:
                continue
            # Fil entrant dans PAGE_OUT (src → PAGE_OUT.SIG)
            src_wire = next((w for w in wires
                             if w["dst"]["bid"] == out_id
                             and w["dst"]["port"] == "SIG"), None)
            if not src_wire:
                continue
            # Un fil virtuel par PAGE_IN consommatrice du signal
            for in_id in lbl_in[sig]:
                # Fil sortant de PAGE_IN (PAGE_IN.SIG → dst)
                dst_wire = next((w for w in wires
                                 if w["src"]["bid"] == in_id
                                 and w["src"]["port"] == "SIG"), None)
                if dst_wire:
                    virtual_wires.append({
                        "src": src_wire["src"],
                        "dst": dst_wire["dst"],
                    })

        # Retirer fils et blocs PAGE_IN/PAGE_OUT du graphe de compilation
        lbl_ids = set(lbl_out.values()) | {bid for ids in lbl_in.values() for bid in ids}
        wires = [w for w in wires
                 if w["src"]["bid"] not in lbl_ids
                 and w["dst"]["bid"] not in lbl_ids]
        wires += virtual_wires
        for bid in lbl_ids:
            blocks.pop(bid, None)

        # ── Bits M temporaires pour blocs logiques → CARITHM/PYBLOCK ─────────
        # M24-M31 réservés pour signaux intermédiaires générés automatiquement.
        _tmp_m_idx  = [24]
        _tmp_m_used: dict = {}   # cache (block_id, port) → M-bit déjà alloué

        def _alloc_mbit(logic_bid, port=""):
            """Alloue (ou réutilise) un bit M temporaire pour un port logique."""
            key = (logic_bid, port)
            if key in _tmp_m_used:
                return _tmp_m_used[key]
            m = f"M{_tmp_m_idx[0]}"
            _tmp_m_idx[0] = 24 if _tmp_m_idx[0] >= 31 else _tmp_m_idx[0] + 1
            _tmp_m_used[key] = m
            return m

        # ── Helpers ───────────────────────────────────────────────────────
        # Index CONN : num → liste de block_ids (pour traversée rapide)
        _conn_by_num: dict = {}
        for _bid, _b in blocks.items():
            if _b.get("type") in ("CONN", "CONN_TX", "CONN_RX"):
                _num = str(_b.get("params", {}).get("num", ""))
                _conn_by_num.setdefault(_num, []).append(_bid)

        def wire_src(dst_bid, dst_port, _visited=None):
            """Retourne (bloc_source, port_source) pour une entrée donnée.

            Traverse transparemment les paires CONN (connecteurs numérotés) :
            un CONN reçoit le signal d'une source (port IN), son jumeau (même num)
            le redistribue (port OUT) — wire_src franchit cette frontière
            automatiquement pour retourner toujours le bloc réel en amont.
            """
            if _visited is None:
                _visited = set()
            for w in wires:
                if w["dst"]["bid"] == dst_bid and w["dst"]["port"] == dst_port:
                    src_bid = w["src"]["bid"]
                    sb      = blocks.get(src_bid)
                    sp      = w["src"]["port"]
                    # ── Traversée CONN pair ──────────────────────────────
                    if sb and sb.get("type") in ("CONN", "CONN_TX", "CONN_RX"):
                        if src_bid in _visited:
                            return None, None
                        _visited.add(src_bid)
                        num = str(sb.get("params", {}).get("num", ""))
                        # Chercher le CONN partenaire (même num, autre id)
                        partner_id = next(
                            (bid for bid in _conn_by_num.get(num, [])
                             if bid != src_bid),
                            None
                        )
                        if partner_id:
                            # Remonter depuis le port IN du CONN partenaire (TX/RX inter-page)
                            return wire_src(partner_id, "IN", _visited)
                        # Fallback : CONN simple pass-through (pas de partenaire)
                        # → remonter directement via le port IN du CONN courant
                        return wire_src(src_bid, "IN", _visited)
                    return sb, sp
            return None, None

        def signal_ref(src_b):
            """Retourne la référence signal d'un bloc source (INPUT/MEM/CONST)."""
            if not src_b: return None
            t = src_b["type"]; p = src_b.get("params", {})
            if t == "INPUT":  return int(p.get("pin", 22))
            if t == "MEM":    return p.get("bit", "M0")
            if t == "CONST":  return p.get("value", 0)
            if t in ("PT_IN","ANA_IN","DS_IN","SENSOR"): return p.get("reg_out", "RF0")
            if t == "MQTT": return p.get("reg_out", "RF0")
            if t == "BACKUP": return p.get("varname", "backup0")
            if t == "AV":     return p.get("reg_out") or p.get("varname", "av0")  # FIX: reg_out = RF register écrit par l'AV
            # FIX : DV câblé vers XOR/OR/AND → retourner reg_out RF* si disponible
            if t == "DV":
                ro = p.get("reg_out")
                if ro and str(ro).startswith("RF"): return ro
                return p.get("varname", "dv0")
            # Blocs analogiques → leur sortie registre
            if t in ("ADD","SUB","MUL","DIV","SCALE","PID","FILT1","AVG",
                     "INTEG","DERIV","DEADB","RAMP","ABS","MIN","MAX","MOD",
                     "SQRT","POW","CLAMP","CLAMP_A","SEL","MUX","COMPH","COMPL"):
                return p.get("reg_out", "RF0")
            if t == "PYBLOCK":
                # Retourner oa1_ref uniquement si c'est vraiment une sortie analogique
                # (quand port non connu). Pour les od* booléens → voir _get_src_ref
                return p.get("oa1_ref") or p.get("reg_out")
            return None

        def analog_src_ref(src_b, src_port=None):
            """Comme signal_ref, mais tient compte du port source pour les blocs
            multi-sorties (CARITHM/PYBLOCK) : utilisé pour résoudre un port PT
            (preset câblé) vers le bon registre RF (oa{N}/od{N}), quel que soit
            le numéro de sortie utilisé — signal_ref() seul renverrait toujours
            oa1_ref par défaut."""
            if not src_b: return None
            t = src_b["type"]; p = src_b.get("params", {})
            if t in ("PYBLOCK", "CARITHM") and src_port:
                sp = src_port.lower()
                ref = p.get(f"{sp}_ref")
                if ref: return ref
            return signal_ref(src_b)

        def bool_ref(src_b):
            """Retourne la référence booléenne d'un bloc source simple."""
            if not src_b: return None
            t = src_b["type"]; p = src_b.get("params", {})
            if t == "INPUT":  return int(p.get("pin", 22))
            if t == "MEM":    return p.get("bit", "M0")
            if t == "DV":     return p.get("varname", "dv0")
            if t == "BACKUP" and p.get("bktype") == "bool": return p.get("varname", "backup0")
            return None

        _LOGIC_TYPES = {"AND", "OR", "NOT", "XOR", "INV", "NAND", "NOR"}

        def bool_ref_for_input(isb, src_port, pre_coils_list):
            """Comme bool_ref, mais gère tous les types de blocs source possibles
            sur un port d{i} de CARITHM/PYBLOCK (blocs logiques, COIL, timer…).

            Pour les blocs logiques (OR, INV…) : alloue un bit M temporaire,
            insère un COIL implicite calculant la condition, retourne le bit M.
            pre_coils_list : liste dans laquelle les COIL implicites sont ajoutés
            (ils seront insérés AVANT le bloc courant dans prog).
            """
            # ── DV câblé : lire son registre RF (reg_out), pas son nom ─────
            # Le moteur écrit toujours la valeur courante du DV (défaut inclus)
            # dans reg_out. Lire le NOM (« dv1 ») ne marche qu'après une action
            # de l'opérateur : tant que dv_vars est vide, read_signal renvoie
            # False même si le DV vaut TRUE par défaut.
            if isb is not None and isb.get("type") == "DV":
                _ro = isb.get("params", {}).get("reg_out")
                if _ro and isinstance(_ro, str) and _ro.startswith("RF"):
                    return _ro
            # ── Cas simples ────────────────────────────────────────────────
            ref = bool_ref(isb)
            if ref is not None:
                return ref
            if isb is None:
                return None
            t = isb["type"]; p_src = isb.get("params", {})

            # ── Bloc logique → prioriser reg_out RF* déjà assigné ──────────
            if t in _LOGIC_TYPES:
                # Si le canvas a assigné un reg_out RF* (ex: RF352 pour OR→CONN_TX),
                # ce registre sera écrit directement par le bloc moteur "or"/"and"...
                # → retourner ce RF directement sans générer de coil implicite.
                reg_out_logic = p_src.get("reg_out")
                if reg_out_logic and str(reg_out_logic).startswith("RF"):
                    return reg_out_logic
                # Sinon : générer un COIL implicite sur bit M temp
                cond = build_cond(isb)
                if cond:
                    m = _alloc_mbit(isb["id"], "out")
                    coil_id = f"__tmp_logic_{isb['id']}"
                    if not any(c.get("id") == coil_id for c in pre_coils_list):
                        pre_coils_list.append({"id": coil_id, "type": "coil",
                                               "condition": cond, "output": m})
                    return m
                return None

            # ── COIL / SET / RESET comme source ───────────────────────────
            if t in ("COIL", "SET", "RESET"):
                m = _alloc_mbit(isb["id"], "Q")
                en_port = {"COIL": "EN", "SET": "S", "RESET": "R"}[t]
                en_src, _ = wire_src(isb["id"], en_port)
                cond = build_cond(en_src)
                if cond:
                    coil_id = f"__tmp_coilq_{isb['id']}"
                    if not any(c.get("id") in (coil_id, isb["id"]) and
                               c.get("output") == m for c in pre_coils_list):
                        pre_coils_list.append({"id": coil_id, "type": "coil",
                                               "condition": cond, "output": m})
                return m

            # ── Sortie od CARITHM / PYBLOCK ────────────────────────────────
            if t in ("CARITHM", "PYBLOCK") and src_port:
                sp = src_port.lower()
                if sp.startswith("od"):
                    return p_src.get(f"{sp}_ref")

            # ── CONN / CONN_TX / CONN_RX avec reg_out RF* ──────────────────
            # Si le connecteur porte déjà un reg_out RF* (ex: RF352),
            # le bloc logique amont y écrit → retourner directement.
            if t in ("CONN", "CONN_TX", "CONN_RX"):
                reg_out_conn = p_src.get("reg_out")
                if reg_out_conn and str(reg_out_conn).startswith("RF"):
                    return reg_out_conn
                # Sinon traverser pour trouver la source réelle
                in_src, in_port = wire_src(isb["id"], "IN")
                if in_src:
                    return bool_ref_for_input(in_src, in_port, pre_coils_list)
                return None

            # ── SR_R / SR_S → bit mémoire ──────────────────────────────────
            if t in ("SR_R", "SR_S"):
                return p_src.get("bit", "M0")

            # ── Timer done → COIL implicite ────────────────────────────────
            if t in ("TON", "TOF", "TP", "WAIT", "WAITH", "PULSE"):
                cond = {"type": "timer_done", "id": isb["id"]}
                m = _alloc_mbit(isb["id"], "done")
                coil_id = f"__tmp_tmr_{isb['id']}"
                if not any(c.get("id") == coil_id for c in pre_coils_list):
                    pre_coils_list.append({"id": coil_id, "type": "coil",
                                           "condition": cond, "output": m})
                return m

            # ── Compteur done → COIL implicite ─────────────────────────────
            if t in ("CTU", "CTD", "CTUD", "RUNTIMCNT"):
                cond = {"type": "counter_done", "id": isb["id"]}
                m = _alloc_mbit(isb["id"], "done")
                coil_id = f"__tmp_ctr_{isb['id']}"
                if not any(c.get("id") == coil_id for c in pre_coils_list):
                    pre_coils_list.append({"id": coil_id, "type": "coil",
                                           "condition": cond, "output": m})
                return m

            # ── COMPH / COMPL / HYST → bit M de leur reg_out ───────────────
            if t in ("COMPH", "COMPL", "HYST"):
                reg = p_src.get("reg_out", "M0")
                if reg.startswith("M"):
                    return reg

            return None

        def build_cond(src_b, src_port=None):
            """Construit une condition booléenne récursive à partir d'un bloc.

            src_port : nom du port SOURCE câblé (ex: 'OD1', 'OA1'), utilisé
            uniquement pour désambiguïser les blocs multi-sorties (CARITHM/PYBLOCK).
            Optionnel pour compatibilité avec les appels existants (IN1/IN2 logique…).
            """
            if not src_b: return None
            t = src_b["type"]; p = src_b.get("params", {})
            if t == "INPUT":
                return {"type": "input", "ref": int(p.get("pin", 22))}
            if t == "MEM":
                return {"type": "input", "ref": p.get("bit", "M0")}
            if t == "DV":
                # Normaliser en minuscules pour cohérence avec _on_dv_write et dv_vars
                return {"type": "input", "ref": p.get("varname", "dv0").lower()}
            if t in ("NOT", "INV"):
                isb, _ = wire_src(src_b["id"], "IN")
                c = build_cond(isb)
                return {"type": "not", "condition": c} if c else None
            if t == "AND":
                # FIX : reg_out RF* disponible → l'utiliser directement
                ro = p.get("reg_out")
                if ro and isinstance(ro, str) and ro.startswith("RF"):
                    return {"type": "input", "ref": ro}
                i1, _ = wire_src(src_b["id"], "IN1")
                i2, _ = wire_src(src_b["id"], "IN2")
                conds = [c for c in [build_cond(i1), build_cond(i2)] if c]
                return {"type": "and", "conditions": conds} if conds else None
            if t == "OR":
                ro = p.get("reg_out")
                if ro and isinstance(ro, str) and ro.startswith("RF"):
                    return {"type": "input", "ref": ro}
                i1, _ = wire_src(src_b["id"], "IN1")
                i2, _ = wire_src(src_b["id"], "IN2")
                conds = [c for c in [build_cond(i1), build_cond(i2)] if c]
                return {"type": "or", "conditions": conds} if conds else None
            if t == "XOR":
                # FIX : si le XOR a un reg_out RF* (assigné par _assignWireRF),
                # l'utiliser directement — c'est le registre écrit par exec_block XOR.
                # Pas besoin de reconstruire la logique booléenne complète.
                ro = p.get("reg_out")
                if ro and isinstance(ro, str) and ro.startswith("RF"):
                    return {"type": "input", "ref": ro}
                # Fallback: reconstruction logique si reg_out absent
                i1, _ = wire_src(src_b["id"], "IN1")
                i2, _ = wire_src(src_b["id"], "IN2")
                c1 = build_cond(i1); c2 = build_cond(i2)
                if c1 and c2:
                    return {"type": "or", "conditions": [
                        {"type": "and", "conditions": [c1, {"type": "not", "condition": c2}]},
                        {"type": "and", "conditions": [{"type": "not", "condition": c1}, c2]},
                    ]}
                return None
            if t == "NAND":
                ro = p.get("reg_out")
                if ro and isinstance(ro, str) and ro.startswith("RF"):
                    return {"type": "input", "ref": ro}
                i1, _ = wire_src(src_b["id"], "IN1")
                i2, _ = wire_src(src_b["id"], "IN2")
                conds = [c for c in [build_cond(i1), build_cond(i2)] if c]
                if conds:
                    return {"type": "not", "condition": {"type": "and", "conditions": conds}}
                return None
            if t == "NOR":
                ro = p.get("reg_out")
                if ro and isinstance(ro, str) and ro.startswith("RF"):
                    return {"type": "input", "ref": ro}
                i1, _ = wire_src(src_b["id"], "IN1")
                i2, _ = wire_src(src_b["id"], "IN2")
                conds = [c for c in [build_cond(i1), build_cond(i2)] if c]
                if conds:
                    return {"type": "not", "condition": {"type": "or", "conditions": conds}}
                return None
            # Sortie timer/compteur → condition indirecte
            if t in ("TON","TOF","TP","WAIT","WAITH","PULSE"):
                return {"type": "timer_done", "id": src_b["id"]}
            if t in ("CTU","CTD","CTUD","RUNTIMCNT"):
                return {"type": "counter_done", "id": src_b["id"]}
            # Sorties COMPH/COMPL/HYST → bit mémoire ou signal direct
            if t in ("COMPH", "COMPL", "HYST", "COMPARE_F"):
                reg = p.get("reg_out", "M0")
                # FIX : le canvas affecte un registre RF* (et non un bit M) comme
                # reg_out du comparateur. Sans ce cas, build_cond() renvoyait None :
                # aucune bobine n'était créée pour l'OUTPUT câblé derrière, et le
                # comparateur n'écrivait que dans son registre RF -> la sortie GPIO
                # ne se déclenchait jamais (comparateur vert, relais au repos).
                if isinstance(reg, str) and (reg.startswith("M") or reg.startswith("RF")):
                    return {"type": "input", "ref": reg}
            # SR_R / SR_S → lire le bit
            if t in ("SR_R", "SR_S"):
                return {"type": "input", "ref": p.get("bit", "M0")}
            # CARITHM / PYBLOCK : n'importe quelle sortie (od{N} booléenne OU
            # oa{N} analogique) peut alimenter une condition — le registre RF
            # écrit par le bloc est directement testable (>0 = vrai) via read_signal.
            # FIX CRITIQUE : auparavant cette branche retournait toujours None,
            # ce qui faisait retomber eval_cond() sur sa valeur par défaut (True)
            # côté moteur → un TON/TOF/TP/WAIT câblé sur un PyBlock/CArithm se
            # déclenchait en permanence, même sans commande active du bloc source.
            if t in ("CARITHM", "PYBLOCK"):
                if src_port:
                    sp = src_port.lower()
                    ref = p.get(f"{sp}_ref")
                    if ref:
                        return {"type": "input", "ref": ref}
                # Port source inconnu (appelant historique) : retomber sur la
                # première sortie plausible plutôt que de perdre le fil.
                ref = p.get("od1_ref") or p.get("oa1_ref") or p.get("reg_out")
                if ref:
                    return {"type": "input", "ref": ref}
                return None
            return None

        def resolve_bool_out(bid, port="Q", _visited=None):
            """Résout la destination booléenne d'un port de sortie.
            Traverse transparemment les paires CONN.
            """
            if _visited is None:
                _visited = set()
            for w in wires:
                if w["src"]["bid"] == bid and w["src"]["port"] == port:
                    dst_bid = w["dst"]["bid"]
                    db = blocks.get(dst_bid)
                    if not db:
                        continue
                    t = db["type"]; pp = db.get("params", {})
                    if t == "OUTPUT":
                        # Priorité : val_ref RF* (variable) > pin GPIO (entier)
                        val_ref = pp.get("val_ref")
                        if val_ref and isinstance(val_ref, str) and val_ref.startswith("RF"):
                            return val_ref
                        return int(pp.get("pin", 17))
                    if t == "MEM":    return pp.get("bit", "M0")
                    if t == "DV":     return pp.get("varname", "dv0")
                    # ── CARITHM / PYBLOCK : destination booléenne ────────
                    # CORRECTION CRITIQUE : si la SOURCE est aussi un CARITHM/PYBLOCK,
                    # le M-bit alloué ici N'EST JAMAIS LU par la destination :
                    # bool_ref_for_input() retourne p_src.get("od{N}_ref") = RF canvas.
                    # → retourner directement le RF canvas de la source.
                    # Pour les autres sources (COIL, timer, logique...) on garde
                    # le M-bit (il est alloué + lu via bool_ref_for_input).
                    if t in ("CARITHM", "PYBLOCK"):
                        _src_b = blocks.get(bid)
                        if _src_b and _src_b.get("type","").upper() in ("CARITHM","PYBLOCK"):
                            _src_p = _src_b.get("params", {})
                            _pu = port.upper()
                            if _pu.startswith("OD") and len(_pu) > 2:
                                _pk = f"od{_pu[2:]}_ref"
                            elif _pu in ("OUT","Q","OUT1"):
                                _pk = "reg_out"
                            else:
                                _pk = f"{port.lower()}_ref"
                            _rf = _src_p.get(_pk)
                            if _rf and isinstance(_rf, str) and _rf.startswith("RF"):
                                return _rf  # RF canvas → écriture dans registers[]
                        return _alloc_mbit(bid, port)  # source COIL/timer → M-bit
                    # ── Traversée CONN pair (sens avant) ─────────────────
                    if t in ("CONN", "CONN_TX", "CONN_RX"):
                        if dst_bid in _visited:
                            continue
                        _visited.add(dst_bid)
                        num = str(pp.get("num", ""))
                        partner_id = next(
                            (i for i in _conn_by_num.get(num, []) if i != dst_bid),
                            None
                        )
                        if partner_id:
                            res = resolve_bool_out(partner_id, "OUT", _visited)
                            if res is not None:
                                return res
                        else:
                            # Fallback : CONN simple pass-through (pas de partenaire)
                            # → suivre en avant via le port OUT du CONN courant
                            res = resolve_bool_out(dst_bid, "OUT", _visited)
                            if res is not None:
                                return res
            return None

        def resolve_reg_out(bid, port="OUT", _visited=None):
            """Résout la destination registre d'un port de sortie analogique.
            Traverse transparemment les paires CONN.
            """
            if _visited is None:
                _visited = set()
            for w in wires:
                if w["src"]["bid"] == bid and w["src"]["port"] == port:
                    dst_bid = w["dst"]["bid"]
                    db = blocks.get(dst_bid)
                    if not db:
                        continue
                    t = db["type"]; pp = db.get("params", {})
                    if t == "STOAV":
                        # STOAV est un puits : il lit le RF câblé par le canvas (reg_a)
                        # et l'écrit dans la variable nommée. Ne PAS renvoyer son
                        # varname : la source écrirait alors dans un registre que le
                        # STOAV ne lit jamais (valeur toujours à 0).
                        _ra = pp.get("reg_a") or pp.get("reg_in")
                        if _ra and isinstance(_ra, str) and _ra.startswith("RF"):
                            return _ra
                    if t in ("BACKUP","AV","STOAV"): return pp.get("reg_out") or pp.get("varname","RF0")
                    if t == "MEM":    return pp.get("bit","M0")
                    if t == "OUTPUT": return int(pp.get("pin",17))
                    # ── CARITHM / PYBLOCK : destination analogique (ex: ET → A2) ──
                    if t in ("CARITHM", "PYBLOCK"):
                        dst_port = w["dst"]["port"]
                        aM = re.match(r"^[aA](\d+)$", dst_port)
                        if aM:
                            ref = pp.get(f"a{aM.group(1)}_ref")
                            if ref: return ref
                    # ── Traversée CONN pair (sens avant) ─────────────────
                    if t in ("CONN", "CONN_TX", "CONN_RX"):
                        if dst_bid in _visited:
                            continue
                        _visited.add(dst_bid)
                        num = str(pp.get("num", ""))
                        partner_id = next(
                            (i for i in _conn_by_num.get(num, []) if i != dst_bid),
                            None
                        )
                        if partner_id:
                            res = resolve_reg_out(partner_id, "OUT", _visited)
                            if res is not None:
                                return res
                        else:
                            # Fallback : CONN simple pass-through
                            res = resolve_reg_out(dst_bid, "OUT", _visited)
                            if res is not None:
                                return res
            return None

        # ── Tri topologique : gauche→droite, puis priorité type (sources avant calculs) ──
        _COMPILE_PRIO = {
            'SENSOR':0,'PT_IN':0,'ANA_IN':0,'DS_IN':0,'AV':0,'DV':0,'BACKUP':0,'STOAV':0,
            'MQTT':0,
            # PAGE_IN/PAGE_OUT supprimés — canvas infini (fils directs)
            'ADD':2,'SUB':2,'MUL':2,'DIV':2,'ABS':2,'SQRT':2,
            'MIN':2,'MAX':2,'MOD':2,'POW':2,'CLAMP':2,'CLAMP_A':2,
            'SCALE':2,'FILT1':2,'AVG':2,'INTEG':2,'DERIV':2,
            'DEADB':2,'RAMP':2,'SEL':2,'MUX':2,
            'PID':3,'PLANCHER':3,'REGULECH':3,'CHAUDIERE':3,
            'SOLAIRE':3,'ZONE':3,'ECS':3,
            'COMPARE_F':4,'COMPH':4,'COMPL':4,'HYST':4,
        }
        sorted_b = sorted(blocks.values(), key=lambda b: (b.get("x", 0), _COMPILE_PRIO.get(b.get("type",""), 3)))
        done = set()
        prog = []

        for b in sorted_b:
            bid = b["id"]; bt = b["type"]; p = b.get("params", {})

            # Blocs purement graphiques — pas de code moteur
            if bt in ("INPUT","OUTPUT","CONST","MEM",
                      "CONN","CONN_TX","CONN_RX",
                      "CARTOUCHE","PAGE_IN","PAGE_OUT"):  # blocs visuels / héritage
                continue

            # ── Initialisation commune pour tous les blocs actifs ───────
            if bid in done:
                continue
            done.add(bid)
            blk = {"id": bid}

            # ── Blocs logiques : compiler en blocs moteur avec in1/in2/reg_out ──
            # Ces blocs doivent écrire leur résultat dans reg_out (RF*)
            # pour que les CONN_TX/RX et PYBLOCK.d{i} puissent les lire.
            if bt in ("AND","OR","NOT","XOR","INV","NAND","NOR"):
                blk["type"] = bt.lower()
                # ── Entrées : lire depuis les fils IN1/IN2/IN ─────────────
                i1sb, i1port = wire_src(bid, "IN1")
                i2sb, i2port = wire_src(bid, "IN2")
                insb, inport  = wire_src(bid, "IN")   # pour INV/NOT

                def _get_src_ref(isb, src_port):
                    """Retourne la RF reference CORRECTE en tenant compte du port source.
                    FIX CRITIQUE : signal_ref(PYBLOCK) retournait oa1_ref (analog)
                    au lieu de od2_ref/od3_ref (booléen). Il faut utiliser le port."""
                    if not isb: return None
                    t2 = isb["type"]; ps = isb.get("params", {})
                    # PYBLOCK/CARITHM : od_ref ou oa_ref selon le port connecté
                    if t2 in ("PYBLOCK", "CARITHM") and src_port:
                        sp = src_port.lower()
                        ref = ps.get(f"{sp}_ref")
                        if ref: return ref
                    # Blocs logiques avec reg_out RF* déjà assigné
                    if t2 in _LOGIC_TYPES:
                        ro = ps.get("reg_out")
                        if ro and str(ro).startswith("RF"): return ro
                    # Fallback standard
                    return signal_ref(isb) or bool_ref(isb)

                blk["in1"] = _get_src_ref(i1sb, i1port) or p.get("reg_a")
                blk["in2"] = _get_src_ref(i2sb, i2port) or p.get("reg_b")
                if bt in ("NOT","INV"):
                    blk["in1"] = _get_src_ref(insb, inport) or blk.get("in1") or p.get("reg_a")
                # ── Sortie : priorité au reg_out du canvas (ex: RF352) ────
                # resolve_bool_out ne traverse pas CONN_TX → on prend directement p.get("reg_out")
                reg_out_canvas = p.get("reg_out")
                reg_out_wired  = resolve_bool_out(bid, "OUT")
                # Priorité : canvas reg_out (RF*) > fil câblé (GPIO/M)
                if reg_out_canvas and str(reg_out_canvas).startswith("RF"):
                    blk["out"] = reg_out_canvas
                elif reg_out_wired is not None:
                    blk["out"] = reg_out_wired
                else:
                    blk["out"] = None
                prog.append(blk)
                continue
            # ── Bobines ──────────────────────────────────────────────────
            if bt in ("COIL","SET","RESET"):
                ep = {"COIL":"EN","SET":"S","RESET":"R"}[bt]
                isb, _ = wire_src(bid, ep)
                cond = build_cond(isb)
                blk["type"] = bt.lower()
                if cond: blk["condition"] = cond
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            # ── MOVE ────────────────────────────────────────────────────
            elif bt == "MOVE":
                isb, _  = wire_src(bid, "IN")
                ensb, _ = wire_src(bid, "EN")
                cond = build_cond(ensb)
                blk["type"] = "coil"
                if cond: blk["condition"] = cond
                out = resolve_bool_out(bid, "OUT")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            # ── Temporisations ───────────────────────────────────────────
            # FIX : IN accepte désormais TOUTES les sources (y compris
            # PYBLOCK/CARITHM, od* ou oa*) grâce à build_cond(isb, isp).
            # PT (preset câblé) et ET (temps écoulé) sont maintenant résolus
            # via wire_src()/resolve_reg_out() vers pt_ref/et_ref — ces ports
            # avaient leur propre bug de collision de registre côté canvas
            # (voir fbd_canvas.js _dstParamKey/_srcParamKey) et n'étaient de
            # toute façon jamais lus/écrits ici.
            elif bt == "TON":
                isb, isp = wire_src(bid, "IN")
                cond = build_cond(isb, isp) or p.get("condition")
                blk["type"] = "timer"
                blk["preset_ms"] = p.get("preset_ms", 1000)
                if cond: blk["condition"] = cond
                ptsb, ptsp = wire_src(bid, "PT")
                pt_ref = analog_src_ref(ptsb, ptsp)
                if pt_ref: blk["pt_ref"] = pt_ref
                et_ref = resolve_reg_out(bid, "ET")
                if et_ref: blk["et_ref"] = et_ref
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "TOF":
                isb, isp = wire_src(bid, "IN")
                cond = build_cond(isb, isp)
                blk["type"] = "tof"
                blk["preset_ms"] = p.get("preset_ms", 1000)
                if cond: blk["condition"] = cond
                ptsb, ptsp = wire_src(bid, "PT")
                pt_ref = analog_src_ref(ptsb, ptsp)
                if pt_ref: blk["pt_ref"] = pt_ref
                et_ref = resolve_reg_out(bid, "ET")
                if et_ref: blk["et_ref"] = et_ref
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "TP":
                isb, isp = wire_src(bid, "IN")
                cond = build_cond(isb, isp)
                blk["type"] = "tp"
                blk["preset_ms"] = p.get("preset_ms", 1000)
                if cond: blk["condition"] = cond
                ptsb, ptsp = wire_src(bid, "PT")
                pt_ref = analog_src_ref(ptsb, ptsp)
                if pt_ref: blk["pt_ref"] = pt_ref
                et_ref = resolve_reg_out(bid, "ET")
                if et_ref: blk["et_ref"] = et_ref
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "WAIT":
                isb, isp = wire_src(bid, "IN")
                cond = build_cond(isb, isp) or p.get("condition")
                blk["type"] = "wait"
                blk["delay_s"] = p.get("delay_s", 5)
                if cond: blk["condition"] = cond
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "WAITH":
                isb, isp = wire_src(bid, "IN")
                cond = build_cond(isb, isp) or p.get("condition")
                blk["type"] = "waith"
                blk["delay_s"] = p.get("delay_s", 5)
                if cond: blk["condition"] = cond
                out = resolve_bool_out(bid, "STS")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "PULSE":
                isb, isp = wire_src(bid, "IN")
                cond = build_cond(isb, isp) or p.get("condition")
                blk["type"] = "pulse"
                blk["duration_s"] = p.get("duration_s", 3)
                if cond: blk["condition"] = cond
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            # ── Compteurs ────────────────────────────────────────────────
            elif bt == "CTU":
                cusb, cusp = wire_src(bid, "CU")
                rsb,  rsp  = wire_src(bid, "R")
                ptsb, ptsp = wire_src(bid, "PV")
                blk["type"]   = "counter"
                blk["preset"] = p.get("preset", 10)
                cond = build_cond(cusb, cusp)
                rst  = build_cond(rsb, rsp)
                if cond: blk["condition"]       = cond
                if rst:  blk["reset_condition"] = rst
                pv_ref = analog_src_ref(ptsb, ptsp)
                if pv_ref: blk["pv_ref"] = pv_ref
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                cv_ref = resolve_reg_out(bid, "CV")
                if cv_ref: blk["cv_ref"] = cv_ref
                prog.append(blk)

            elif bt == "CTD":
                cdsb, cdsp = wire_src(bid, "CD")
                ldsb, ldsp = wire_src(bid, "LD")
                ptsb, ptsp = wire_src(bid, "PV")
                blk["type"]   = "ctd"
                blk["preset"] = p.get("preset", 10)
                cd = build_cond(cdsb, cdsp)
                ld = build_cond(ldsb, ldsp)
                if cd: blk["cd_cond"] = cd
                if ld: blk["ld_cond"] = ld
                pv_ref = analog_src_ref(ptsb, ptsp)
                if pv_ref: blk["pv_ref"] = pv_ref
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                cv_ref = resolve_reg_out(bid, "CV")
                if cv_ref: blk["cv_ref"] = cv_ref
                prog.append(blk)

            elif bt == "CTUD":
                cusb, cusp = wire_src(bid, "CU")
                cdsb, cdsp = wire_src(bid, "CD")
                rsb,  rsp  = wire_src(bid, "R")
                ldsb, ldsp = wire_src(bid, "LD")
                ptsb, ptsp = wire_src(bid, "PV")
                blk["type"]   = "ctud"
                blk["preset"] = p.get("preset", 10)
                cu = build_cond(cusb, cusp); cd = build_cond(cdsb, cdsp)
                rst = build_cond(rsb, rsp);  ld = build_cond(ldsb, ldsp)
                if cu:  blk["cu_cond"]          = cu
                if cd:  blk["cd_cond"]          = cd
                if rst: blk["reset_condition"]  = rst
                if ld:  blk["ld_cond"]          = ld
                pv_ref = analog_src_ref(ptsb, ptsp)
                if pv_ref: blk["pv_ref"] = pv_ref
                out = resolve_bool_out(bid, "Q")
                if out is not None: blk["output"] = out
                cv_ref = resolve_reg_out(bid, "CV")
                if cv_ref: blk["cv_ref"] = cv_ref
                prog.append(blk)

            # ── Comparaison ──────────────────────────────────────────────
            elif bt in ("GT","GE","LT","EQ","NE"):
                i1sb, _ = wire_src(bid, "IN1")
                i2sb, _ = wire_src(bid, "IN2")
                op_map = {"GT":"gt","GE":"ge","LT":"lt","EQ":"eq","NE":"ne"}
                blk["type"] = "compare"
                blk["op"]   = op_map[bt]
                ref_a = signal_ref(i1sb)
                ref_b = signal_ref(i2sb)
                if ref_a is not None: blk["ref_a"] = ref_a
                if ref_b is not None: blk["ref_b"] = ref_b
                else: blk["val_b"] = 0
                out = resolve_bool_out(bid, "OUT")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "COMPARE_F":
                blk["type"] = "compare_f"
                blk["reg_ref"]   = p.get("reg_ref", "RF0")
                blk["threshold"] = p.get("threshold", 80.0)
                blk["hysteresis"]= p.get("hysteresis", 1.0)
                blk["op"]        = p.get("op", "gt")
                out = resolve_bool_out(bid, "GT")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            # ── Bascules SR ──────────────────────────────────────────────
            elif bt in ("SR","RS"):
                sp = "S1" if bt == "SR" else "S"
                rp = "R"  if bt == "SR" else "R1"
                ssb, _ = wire_src(bid, sp)
                rsb, _ = wire_src(bid, rp)
                sc = build_cond(ssb); rc = build_cond(rsb)
                out = resolve_bool_out(bid, "Q1")
                _rf_fb = p.get("reg_out")
                _rf_fb = _rf_fb if isinstance(_rf_fb, str) and _rf_fb.startswith("RF") else None
                if sc:
                    sb = {"type":"set",   "id":f"{bid}_S","condition":sc}
                    if out is not None: sb["output"] = out
                    if _rf_fb: sb["reg_out"] = _rf_fb
                    prog.append(sb)
                if rc:
                    rb = {"type":"reset", "id":f"{bid}_R","condition":rc}
                    if out is not None: rb["output"] = out
                    if _rf_fb: rb["reg_out"] = _rf_fb
                    prog.append(rb)

            elif bt in ("SR_R", "SR_S"):
                ssb, _ = wire_src(bid, "SET")
                rsb, _ = wire_src(bid, "RES")
                sc = build_cond(ssb); rc = build_cond(rsb)
                blk["type"]    = bt.lower()
                blk["bit"]     = p.get("bit", "M0")
                if sc: blk["set_cond"] = sc
                if rc: blk["res_cond"] = rc
                out = resolve_bool_out(bid, "STS")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            # ── Variables / Persistance ───────────────────────────────────
            elif bt == "BACKUP":
                # BACKUP : port VAL bidirectionnel
                # → val_in = source câblée sur VAL (écriture)
                # → val_out = registre où exposer la valeur lue (lecture)
                isb, _ = wire_src(bid, "VAL")
                bktype = p.get("bktype", "float")
                if bktype == "bool":
                    # FIX: pour les sources booléennes (DV, INPUT, MEM…)
                    # utiliser bool_ref() qui gère les blocs DV (signal_ref ne les couvre pas)
                    ref_in = bool_ref(isb) or signal_ref(isb)
                else:
                    ref_in  = signal_ref(isb)   # source analogique câblée
                ref_out = resolve_reg_out(bid, "VAL") or p.get("reg_out")
                blk["type"]    = "backup"
                blk["varname"] = p.get("varname", "backup0")
                blk["default"] = p.get("default", 0.0)
                blk["bktype"]  = bktype
                if ref_in  is not None: blk["val_in"]  = ref_in
                if ref_out is not None: blk["val_out"] = ref_out
                bool_out = resolve_bool_out(bid, "VAL")
                if bool_out is not None: blk["output"] = bool_out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "AV":
                blk["type"]    = "av"
                blk["varname"] = p.get("varname", "av0")
                blk["default"] = p.get("default", 0.0)
                val_out = resolve_reg_out(bid, "VAL") or p.get("reg_out")
                if val_out: blk["val_out"] = val_out
                bool_out = resolve_bool_out(bid, "OUT")
                if bool_out is not None: blk["output"] = bool_out
                prog.append(blk)   # AV expose déjà val_out (reg_out géré ci-dessus)

            elif bt == "DV":
                blk["type"]    = "dv"
                blk["varname"] = p.get("varname", "dv0").lower()  # normalise casse
                blk["default"] = p.get("default", False)
                # Résoudre le fil de sortie DV.OUT → OUTPUT/MEM/RF
                dv_out = resolve_bool_out(bid, "OUT")
                if dv_out is not None:
                    blk["output"] = dv_out
                # FIX CRITIQUE : si le DV est câblé vers un OR/AND/CONN (pas OUTPUT),
                # reg_out=RF* est dans les params canvas → l'ajouter explicitement
                # sinon le moteur n'écrit jamais dans RF130/RF131/etc.
                dv_reg = p.get("reg_out")
                if dv_reg and str(dv_reg).startswith("RF"):
                    blk["reg_out"] = dv_reg
                prog.append(blk)

            elif bt == "BOOLEAN":
                n_in = int(p.get("n_in", 4))
                n_out = int(p.get("n_out", 1))
                blk["type"]         = "boolean"
                blk["n_in"]         = n_in
                blk["n_out"]        = n_out
                blk["invert_o1"]    = bool(p.get("invert_o1", False))
                blk["invert_o2"]    = bool(p.get("invert_o2", False))
                rows = 1 << n_in
                tt = p.get("truth_table") or [[0]*n_out for _ in range(rows)]
                if len(tt) != rows:
                    tt = [[0]*n_out for _ in range(rows)]
                blk["truth_table"]  = tt
                # FIX : utiliser bool_ref_for_input pour gérer DV/CONN/logique
                _pre_coils_bool = []
                for i in range(1, n_in + 1):
                    isb, src_port = wire_src(bid, f"I{i}")
                    # Priorité: bool_ref_for_input gère tous les types de source
                    ref = bool_ref_for_input(isb, src_port, _pre_coils_bool)
                    if ref is None:
                        ref = bool_ref(isb)  # fallback
                    blk[f"in{i}_ref"] = ref
                prog.extend(_pre_coils_bool)
                # Sorties O1/O2 : résoudre vers GPIO, M* ou RF*
                out1 = resolve_bool_out(bid, "O1")
                out2 = resolve_bool_out(bid, "O2") if n_out >= 2 else None
                # Si pas de fil câblé, utiliser le reg_out du canvas pour O1/O2
                if out1 is None: out1 = p.get("reg_out_o1") or p.get("reg_out")
                if out2 is None: out2 = p.get("reg_out_o2")
                if out1 is not None: blk["out1_ref"] = out1
                if out2 is not None: blk["out2_ref"] = out2
                prog.append(blk)

            elif bt == "STOAV":
                isb, _sp = wire_src(bid, "IN")
                ref = analog_src_ref(isb, _sp)   # tient compte du port (OA2 ≠ OA1)
                blk["type"]    = "stoav"
                blk["varname"] = p.get("varname", "av0")
                if ref is not None: blk["reg_in"] = ref
                prog.append(blk)

            elif bt == "STOAP":
                isb, _sp = wire_src(bid, "IN")
                ref = analog_src_ref(isb, _sp)
                blk["type"]    = "stoap"
                blk["varname"] = p.get("varname", "timer0.TimerTime")
                if ref is not None: blk["reg_in"] = ref
                prog.append(blk)

            elif bt == "LOCALTIME":
                blk["type"]     = "localtime"
                blk["out_hour"] = p.get("reg_hour") or p.get("out_hour", "RF13")
                blk["out_mday"] = p.get("reg_mday") or p.get("out_mday", "RF14")
                blk["out_wday"] = p.get("reg_wday") or p.get("out_wday", "RF15")
                if p.get("reg_min"):  blk["out_min"] = p["reg_min"]
                if p.get("reg_sec"):  blk["out_sec"] = p["reg_sec"]
                prog.append(blk)

            elif bt == "MQTT":
                blk["type"]     = "mqtt"
                blk["topic"]    = p.get("topic", "")
                blk["val_type"] = p.get("val_type", "float")   # float|bool
                blk["retain"]   = bool(p.get("retain", False))
                # Subscribe : le topic ecrit dans reg_out (RF*)
                ro = p.get("reg_out", "")
                if ro: blk["reg_out"] = ro
                # Publish : reg_in (RF*) est publie vers le topic
                ri = p.get("reg_in", "")
                if ri: blk["reg_in"] = ri
                # FIX : stale_timeout (watchdog "topic fige") n'etait jamais
                # recopie dans le bloc compile -> reste bien dans le .plcproj
                # (panneau proprietes) mais disparait a chaque compilation, donc
                # le watchdog cote mqtt_bridge.py ne s'activait jamais, meme
                # configure et redeploye.
                st = p.get("stale_timeout")
                if st:
                    try:
                        stf = float(st)
                        if stf > 0:
                            blk["stale_timeout"] = stf
                    except (TypeError, ValueError):
                        pass
                prog.append(blk)

            # ── Actionneurs ───────────────────────────────────────────────
            # ── Blocs Métier ────────────────────────────────────────────────────────
            elif bt == "PLANCHER":
                blk["type"]          = "plancher"
                blk["name"]          = p.get("name", "Plancher")
                # ─ Sondes : port câblé (T_AMB/T_DEP/T_RET) → ref signal,
                #   sinon fallback sur pv_ref_xxx configuré dans params
                t_amb_src, _ = wire_src(bid, "T_AMB")
                t_dep_src, _ = wire_src(bid, "T_DEP")
                t_ret_src, _ = wire_src(bid, "T_RET")
                sp_src,    _ = wire_src(bid, "SP")
                en_src,    _ = wire_src(bid, "EN")
                blk["pv_ref_amb"]    = signal_ref(t_amb_src) or p.get("pv_ref_amb", "RF0")
                blk["pv_ref_depart"] = signal_ref(t_dep_src) or p.get("pv_ref_depart", "")
                blk["pv_ref_retour"] = signal_ref(t_ret_src) or p.get("pv_ref_retour", "")
                blk["sp_ref"]        = signal_ref(sp_src) or None  # consigne dynamique
                blk["sp"]            = float(p.get("sp", 20.0))    # consigne fixe fallback
                blk["en_cond"]       = build_cond(en_src) or None
                blk["max_depart"]    = float(p.get("max_depart", 45.0))
                blk["min_delta"]     = float(p.get("min_delta", 3.0))
                blk["kp"]            = float(p.get("kp", 2.0))
                blk["ki"]            = float(p.get("ki", 0.1))
                blk["kd"]            = float(p.get("kd", 0.5))
                blk["dead_band"]     = float(p.get("dead_band", 0.5))
                # ─ Sorties : V3V_OUV, V3V_FER, CIRC (nouvelle architecture)
                blk["out_v3v_ouv"]   = p.get("out_v3v_ouv") or p.get("out_vanne", "k7")
                blk["out_v3v_fer"]   = p.get("out_v3v_fer", "k8")
                blk["out_circ"]      = p.get("out_circ") or p.get("out_pompe", "k9")
                blk["reg_out"]       = p.get("reg_out", "RF2")
                blk["reg_depart"]    = p.get("reg_depart", "RF0")
                blk["reg_retour"]    = p.get("reg_retour", "RF5")
                blk["reg_delta"]     = p.get("reg_delta", "RF15")
                blk["min_temp"]      = float(p.get("min_temp", 5.0))
                blk["max_temp"]      = float(p.get("max_temp", 35.0))
                prog.append(blk)

            elif bt == "CHAUDIERE":
                blk["type"]          = "chaudiere"
                blk["name"]          = p.get("name", "Chaudière")
                blk["pv_ref_retour"] = p.get("pv_ref_retour", "RF1")
                blk["pv_ref_depart"] = p.get("pv_ref_depart", "RF2")
                blk["sp"]            = float(p.get("sp", 65.0))
                blk["hysteresis"]    = float(p.get("hysteresis", 3.0))
                blk["min_on_s"]      = int(p.get("min_on_s", 60))
                blk["min_off_s"]     = int(p.get("min_off_s", 30))
                blk["max_depart"]    = float(p.get("max_depart", 90.0))
                blk["out_brulee"]    = p.get("out_brulee", "k3")
                blk["out_pompe"]     = p.get("out_pompe", "k4")
                prog.append(blk)

            elif bt == "SOLAR":
                blk["type"]             = "solar"
                blk["name"]             = p.get("name", "Solaire")
                blk["pv_ref_capteur"]   = p.get("pv_ref_capteur", "RF0")
                blk["pv_ref_ecs"]       = p.get("pv_ref_ecs", "RF3")
                blk["pv_ref_chauf"]     = p.get("pv_ref_chauf", "")
                blk["delta_on"]         = float(p.get("delta_on", 8.0))
                blk["delta_off"]        = float(p.get("delta_off", 3.0))
                blk["sp_ecs"]           = float(p.get("sp_ecs", 60.0))
                blk["sp_chauf"]         = float(p.get("sp_chauf", 50.0))
                blk["max_capteur"]      = float(p.get("max_capteur", 120.0))
                blk["min_capteur"]      = float(p.get("min_capteur", 5.0))
                blk["pump_mode"]        = p.get("pump_mode", "on_off")
                blk["out_pompe"]        = p.get("out_pompe", "k1")
                blk["out_pompe_av"]     = p.get("out_pompe_av", "")
                blk["pump_min_pct"]     = float(p.get("pump_min_pct", 10.0))
                blk["pump_delta_max"]   = float(p.get("pump_delta_max", 30.0))
                blk["out_vanne_ecs"]    = p.get("out_vanne_ecs", "k2")
                blk["out_vanne_chauf"]  = p.get("out_vanne_chauf", "k3")
                blk["reg_delta"]          = p.get("reg_delta", "RF12")
                blk["reg_rendement"]      = p.get("reg_rendement", "RF13")
                blk["reg_vitesse_pompe"]  = p.get("reg_vitesse_pompe", "RF14")
                blk["min_capteur"]        = float(p.get("min_capteur", 5.0))
                blk["antigel_mode"]       = p.get("antigel_mode", "off")
                blk["antigel_temp_source"]= float(p.get("antigel_temp_source", 30.0))
                prog.append(blk)

            elif bt == "ZONE_CHAUF":
                blk["type"]         = "zone_chauf"
                blk["name"]         = p.get("name", "Zone")
                blk["pv_ref"]       = p.get("pv_ref", "RF0")
                blk["sp"]           = float(p.get("sp", 20.0))
                blk["hysteresis"]   = float(p.get("hysteresis", 0.5))
                blk["out_vanne"]    = p.get("out_vanne", "k5")
                blk["delay_open_s"] = int(p.get("delay_open_s", 120))
                blk["delay_close_s"]= int(p.get("delay_close_s", 120))
                prog.append(blk)

            elif bt == "ECS_BLOC":
                blk["type"]         = "ecs_bloc"
                blk["name"]         = p.get("name", "ECS")
                blk["pv_ref_ecs"]   = p.get("pv_ref_ecs", "RF3")
                blk["pv_ref_prim"]  = p.get("pv_ref_prim", "RF4")
                blk["sp_ecs"]       = float(p.get("sp_ecs", 55.0))
                blk["sp_antileg"]   = float(p.get("sp_antileg", 65.0))
                blk["antileg_day"]  = int(p.get("antileg_day", 0))
                blk["antileg_hour"] = int(p.get("antileg_hour", 3))
                blk["hysteresis"]   = float(p.get("hysteresis", 2.0))
                blk["out_pompe"]    = p.get("out_pompe", "k6")
                prog.append(blk)

            elif bt == "PROG_H":
                ensb,  _ = wire_src(bid, "EN")
                vacsb, _ = wire_src(bid, "VAC")
                en_cond  = build_cond(ensb)
                vac_cond = build_cond(vacsb)
                blk["type"]       = "prog_h"
                blk["name"]       = p.get("name", "Planning")
                blk["hebdo_mode"] = p.get("hebdo_mode", False)
                blk["sp_jour"]    = float(p.get("sp_jour", 20.0))
                blk["sp_nuit"]    = float(p.get("sp_nuit", 17.0))
                blk["sp_vac"]     = float(p.get("sp_vac",  15.0))
                blk["h_debut_j"]  = int(p.get("h_debut_j", 6))
                blk["m_debut_j"]  = int(p.get("m_debut_j", 30))
                blk["h_fin_j"]    = int(p.get("h_fin_j",   22))
                blk["m_fin_j"]    = int(p.get("m_fin_j",    0))
                # Planning hebdomadaire (d0=Lun … d6=Dim)
                for _di in range(7):
                    _key = f"d{_di}"
                    if _key in p:
                        blk[_key] = p[_key]
                blk["reg_sp"]     = p.get("reg_sp",     "RF5")
                # Sorties : priorité fil câblé > paramètre
                blk["out_jour"]   = p.get("out_jour",   "")
                blk["out_vac_dv"] = p.get("out_vac_dv", "")
                blk["out_actif"]  = p.get("out_actif",  "")
                _jour_wire = resolve_bool_out(bid, "JOUR")
                if _jour_wire   is not None: blk["out_jour"]   = _jour_wire
                _vac_wire  = resolve_bool_out(bid, "VAC_OUT")
                if _vac_wire    is not None: blk["out_vac_dv"] = _vac_wire
                if en_cond:  blk["condition"] = en_cond
                if vac_cond: blk["cond_vac"]  = vac_cond
                prog.append(blk)

            elif bt == "CONTACTOR":
                isb, _ = wire_src(bid, "ON")
                cond = build_cond(isb) or p.get("condition")
                blk["type"] = "contactor"
                blk["name"] = p.get("name", "K?")
                blk["pin"]  = int(p.get("pin", 17))
                if cond: blk["condition"] = cond
                prog.append(blk)

            elif bt == "VALVE3V":
                incb, _ = wire_src(bid, "OINC")
                decb, _ = wire_src(bid, "ODEC")
                blk["type"]     = "valve3v"
                blk["name"]     = p.get("name", "V3V")
                blk["pin_inc"]  = int(p.get("pin_inc", 20))
                blk["pin_dec"]  = int(p.get("pin_dec", 21))
                ci = build_cond(incb); cd = build_cond(decb)
                if ci: blk["cond_inc"] = ci
                if cd: blk["cond_dec"] = cd
                # Sorties logiques : Q_OUV = état ouverture, Q_FER = état fermeture
                out_inc = resolve_bool_out(bid, "Q_OUV")
                out_dec = resolve_bool_out(bid, "Q_FER")
                if out_inc is not None: blk["out_inc"] = out_inc
                if out_dec is not None: blk["out_dec"] = out_dec
                prog.append(blk)

            elif bt == "RUNTIMCNT":
                runsb, run_port = wire_src(bid, "RUN")
                rstsb, _        = wire_src(bid, "RST")
                cond  = build_cond(runsb) or p.get("condition")
                # FIX inter-pages : PYBLOCK.od{N} transmis via PAGE_OUT→PAGE_IN
                # build_cond retourne None pour PYBLOCK → condition directe via RF
                if cond is None and runsb and runsb.get("type") == "PYBLOCK" and run_port:
                    sp = run_port.lower()
                    if sp.startswith("od"):
                        od_rf = runsb.get("params", {}).get(f"{sp}_ref")
                        if od_rf:
                            cond = {"type": "input", "ref": od_rf}
                rcond = build_cond(rstsb) or p.get("reset_condition")
                blk["type"]        = "runtimcnt"
                blk["name"]        = p.get("name", p.get("label", "Compteur1"))
                blk["label"]       = p.get("label", p.get("name", "Compteur1"))
                blk["reg_starts"]  = p.get("reg_starts", "")
                blk["reg_total"]   = p.get("reg_total", "")
                blk["reg_runtime"] = p.get("reg_runtime", "")
                if cond:  blk["condition"]       = cond
                if rcond: blk["reset_condition"] = rcond
                prog.append(blk)

            # ── Capteurs analogiques ──────────────────────────────────────
            elif bt == "PT_IN":
                blk["type"]       = "pt_in"
                blk["analog_ref"] = p.get("analog_ref", "PT0")
                blk["reg_out"]    = p.get("reg_out", "RF0")
                prog.append(blk)

            elif bt == "ANA_IN":
                blk["type"]       = "ana_in"
                blk["analog_ref"] = p.get("analog_ref", "ANA0")
                blk["reg_out"]    = p.get("reg_out", "RF1")
                prog.append(blk)

            elif bt == "DS_IN":
                blk["type"]       = "ds_in"
                blk["analog_ref"] = p.get("analog_ref", "DS0")
                blk["rom_id"]     = p.get("rom_id", "")
                blk["resolution"] = p.get("resolution", 12)
                blk["reg_out"]    = p.get("reg_out", "RF2")
                prog.append(blk)

            elif bt == "SENSOR":
                blk["type"]       = "sensor"
                blk["ref"]        = p.get("ref", "ANA0")
                blk["name"]       = p.get("name", p.get("ref", "ANA0"))
                blk["correction"] = p.get("correction", 0.0)
                blk["reg_out"]    = p.get("reg_out", "RF0")
                prog.append(blk)

            # ── Calcul analogique ─────────────────────────────────────────
            elif bt in ("ADD","SUB","MUL","DIV"):
                i1sb, _ = wire_src(bid, "IN1")
                i2sb, _ = wire_src(bid, "IN2")
                blk["type"]    = bt.lower()
                blk["reg_a"]   = signal_ref(i1sb) or p.get("reg_a", "RF0")
                blk["reg_b"]   = signal_ref(i2sb) or p.get("reg_b", "RF1")
                blk["reg_out"] = p.get("reg_out", "RF2")
                prog.append(blk)

            elif bt in ("ABS","SQRT"):
                isb, _ = wire_src(bid, "IN")
                blk["type"]    = bt.lower()
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out", "RF1")
                prog.append(blk)

            elif bt in ("MIN","MAX","MOD","POW"):
                i1sb, _ = wire_src(bid, "IN1" if bt!="POW" else "BASE")
                i2sb, _ = wire_src(bid, "IN2" if bt!="POW" else "EXP")
                blk["type"]    = bt.lower()
                blk["reg_a"]   = signal_ref(i1sb) or p.get("reg_a","RF0")
                blk["reg_b"]   = signal_ref(i2sb) or p.get("reg_b","RF1")
                blk["reg_out"] = p.get("reg_out","RF2")
                prog.append(blk)

            elif bt in ("CLAMP","CLAMP_A"):
                isb, _ = wire_src(bid, "IN")
                blk["type"]    = bt.lower()
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["lo"]      = p.get("lo", 0.0)
                blk["hi"]      = p.get("hi", 100.0)
                out = resolve_bool_out(bid, "CLIP")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "SEL":
                gsb,  _ = wire_src(bid, "G")
                i0sb, _ = wire_src(bid, "IN0")
                i1sb, _ = wire_src(bid, "IN1")
                blk["type"]    = "sel"
                blk["in0"]     = signal_ref(i0sb) or p.get("in0","RF0")
                blk["in1"]     = signal_ref(i1sb) or p.get("in1","RF1")
                blk["reg_out"] = p.get("reg_out","RF2")
                sel_c = build_cond(gsb)
                if sel_c: blk["sel_cond"] = sel_c
                prog.append(blk)

            elif bt == "MUX":
                idxsb, _ = wire_src(bid, "IDX")
                blk["type"]    = "mux"
                blk["idx_ref"] = signal_ref(idxsb) or p.get("idx_ref","RF0")
                blk["n_in"]    = p.get("n_in", 4)
                for i in range(p.get("n_in", 4)):
                    insb, _ = wire_src(bid, f"IN{i}")
                    blk[f"in{i}"] = signal_ref(insb) or p.get(f"in{i}", f"RF{i}")
                blk["reg_out"] = p.get("reg_out","RF4")
                prog.append(blk)

            elif bt == "COMPH":
                # FIX CRITIQUE : blk["ref"] prenait le param canvas brut, qui
                # ne vaut rien quand l'entrée IN passe par une paire CONN (le
                # CONN est un bloc "purement graphique" jamais compilé — voir
                # plus haut — donc son reg_out n'est jamais réécrit). wire_src()
                # traverse les paires CONN pour retrouver la VRAIE source ;
                # analog_src_ref() en extrait le registre réellement écrit
                # (ex: le reg_out d'un ADD/SENSOR en amont).
                _isb, _isp = wire_src(bid, "IN")
                _ref_src   = analog_src_ref(_isb, _isp)
                blk["type"]    = "comph"
                blk["ref"]     = _ref_src or p.get("ref","RF0")
                blk["high"]    = p.get("high", 80.0)
                blk["hyst"]    = p.get("hyst", 0.5)
                # FIX : seuil câblé sur le port HIG (AV, ADD, CONN...) — sans ça
                # seul le champ "high" tapé dans le bloc était transmis aux
                # moteurs et le fil HIG était ignoré.
                _hsb, _hsp = wire_src(bid, "HIG")
                _hv = analog_src_ref(_hsb, _hsp)
                if isinstance(_hv, str) and _hv.startswith("RF"):
                    blk["high_ref"] = _hv
                elif isinstance(_hv, (int, float)) and not isinstance(_hv, bool):
                    blk["high"] = float(_hv)          # CONST câblée
                blk["reg_out"] = p.get("reg_out","M0")
                out = resolve_bool_out(bid, "HL")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "COMPL":
                # FIX CRITIQUE : même correctif que COMPH ci-dessus.
                _isb, _isp = wire_src(bid, "IN")
                _ref_src   = analog_src_ref(_isb, _isp)
                blk["type"]    = "compl"
                blk["ref"]     = _ref_src or p.get("ref","RF0")
                blk["low"]     = p.get("low", 10.0)
                blk["hyst"]    = p.get("hyst", 0.5)
                # FIX : seuil câblé sur le port LOW (cf. COMPH ci-dessus)
                _lsb, _lsp = wire_src(bid, "LOW")
                _lv = analog_src_ref(_lsb, _lsp)
                if isinstance(_lv, str) and _lv.startswith("RF"):
                    blk["low_ref"] = _lv
                elif isinstance(_lv, (int, float)) and not isinstance(_lv, bool):
                    blk["low"] = float(_lv)           # CONST câblée
                blk["reg_out"] = p.get("reg_out","M1")
                out = resolve_bool_out(bid, "LL")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "FILT1":
                isb, _ = wire_src(bid, "IN")
                blk["type"]    = "filt1"
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["tc_s"]    = p.get("tc_s", 10.0)
                prog.append(blk)

            elif bt == "AVG":
                isb, _ = wire_src(bid, "IN")
                blk["type"]    = "avg"
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["n"]       = p.get("n", 10)
                prog.append(blk)

            elif bt == "INTEG":
                isb, _  = wire_src(bid, "IN")
                resb, _ = wire_src(bid, "RES")
                blk["type"]    = "integ"
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["ki"]      = p.get("ki", 1.0)
                blk["lo"]      = p.get("lo", -1e9)
                blk["hi"]      = p.get("hi",  1e9)
                rc = build_cond(resb)
                if rc: blk["reset_cond"] = rc
                out = resolve_bool_out(bid, "MAX")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "DERIV":
                isb, _ = wire_src(bid, "IN")
                blk["type"]    = "deriv"
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["kd"]      = p.get("kd", 1.0)
                prog.append(blk)

            elif bt == "DEADB":
                isb, _ = wire_src(bid, "IN")
                blk["type"]    = "deadb"
                blk["reg_in"]  = signal_ref(isb) or p.get("reg_in","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["dead"]    = p.get("dead", 1.0)
                out = resolve_bool_out(bid, "DEAD")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "RAMP":
                spsb, _ = wire_src(bid, "SP")
                blk["type"]    = "ramp"
                blk["reg_sp"]  = signal_ref(spsb) or p.get("reg_sp","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["rate"]    = p.get("rate", 1.0)
                out = resolve_bool_out(bid, "DONE")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "HYST":
                isb, _ = wire_src(bid, "IN")
                blk["type"]   = "hyst"
                blk["reg_in"] = signal_ref(isb) or p.get("reg_in","RF0")
                blk["sp"]     = p.get("sp", 50.0)
                blk["band"]   = p.get("band", 2.0)
                out = resolve_bool_out(bid, "OUT")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            elif bt == "SCALE":
                blk["type"]    = "scale"
                blk["reg_ref"] = p.get("reg_ref","RF0")
                blk["reg_out"] = p.get("reg_out","RF1")
                blk["in_lo"]   = p.get("in_lo", 0.0)
                blk["in_hi"]   = p.get("in_hi", 5.0)
                blk["out_lo"]  = p.get("out_lo", 0.0)
                blk["out_hi"]  = p.get("out_hi",100.0)
                prog.append(blk)

            elif bt == "PID":
                blk["type"]    = "pid"
                blk["pv_ref"]  = p.get("pv_ref","RF0")
                blk["setpoint"]= p.get("setpoint", 50.0)
                blk["kp"]      = p.get("kp", 1.0)
                blk["ki"]      = p.get("ki", 0.1)
                blk["kd"]      = p.get("kd", 0.0)
                blk["out_min"] = p.get("out_min", 0.0)
                blk["out_max"] = p.get("out_max",100.0)
                blk["reg_out"] = p.get("reg_out","RF3")
                out = resolve_bool_out(bid, "OUT")
                if out is not None: blk["output"] = out
                _rf_fb = p.get("reg_out")
                if isinstance(_rf_fb, str) and _rf_fb.startswith("RF"): blk["reg_out"] = _rf_fb
                prog.append(blk)

            # ── CArithm ───────────────────────────────────────────────────
            elif bt == "CARITHM":
                blk["type"] = "carithm"
                blk["code"] = p.get("code","")
                blk["name"] = p.get("name","CArithm")
                blk["n_a"]  = int(p.get("n_a",  2))
                blk["n_d"]  = int(p.get("n_d",  1))
                blk["n_i"]  = int(p.get("n_i",  0))
                blk["n_oa"] = int(p.get("n_oa", 1))
                blk["n_od"] = int(p.get("n_od", 1))
                blk["n_oi"] = int(p.get("n_oi", 0))
                # Connecter les ports d'entrée analogiques A1..A8
                for i in range(1, int(p.get("n_a",0))+1):
                    isb, _ = wire_src(bid, f"A{i}")
                    ref = signal_ref(isb)
                    # Priorité : fil > param existant > fallback RF*
                    blk[f"a{i}_ref"] = ref if ref is not None else p.get(f"a{i}_ref", f"RF{i-1}")
                # Entrées booléennes d1..d7
                # FIX: bool_ref_for_input gère OR/INV/XOR/AND/COIL/Timer → bit M temp
                _pre_coils_ca = []
                for i in range(1, int(p.get("n_d",0))+1):
                    isb, src_port = wire_src(bid, f"d{i}")
                    ref = bool_ref_for_input(isb, src_port, _pre_coils_ca)
                    blk[f"d{i}_ref"] = ref if ref is not None else p.get(f"d{i}_ref")
                prog.extend(_pre_coils_ca)   # COIL implicites AVANT le CARITHM
                # Entrées entières I1..I2
                for i in range(1, int(p.get("n_i",0))+1):
                    isb, _ = wire_src(bid, f"I{i}")
                    ref = signal_ref(isb)
                    blk[f"i{i}_ref"] = ref if ref is not None else p.get(f"i{i}_ref", f"RF{12+i}")
                # Sorties OA1..OA8
                for i in range(1, int(p.get("n_oa",0))+1):
                    ref = resolve_reg_out(bid, f"OA{i}")
                    # Priorité : fil > param existant > fallback RF*
                    blk[f"oa{i}_ref"] = ref if ref is not None else p.get(f"oa{i}_ref", f"RF{i-1}")
                # Sorties od1..od8
                for i in range(1, int(p.get("n_od",0))+1):
                    # Priorité : RF canvas déjà assigné > resolve_bool_out
                    canvas_ref = p.get(f"od{i}_ref")
                    if canvas_ref and isinstance(canvas_ref, str) and canvas_ref.startswith("RF"):
                        blk[f"od{i}_ref"] = canvas_ref
                    else:
                        ref = resolve_bool_out(bid, f"od{i}")
                        blk[f"od{i}_ref"] = ref if ref is not None else canvas_ref
                # Sortie OI1
                if p.get("n_oi",0) > 0:
                    blk["oi1_ref"] = resolve_reg_out(bid,"OI1") or "RF15"
                prog.append(blk)
            elif bt == "PYBLOCK":
                blk["type"] = "pyblock"
                blk["code"] = p.get("code", "")
                blk["name"] = p.get("name", "PyBlock")
                blk["n_a"]  = int(p.get("n_a",  2))
                blk["n_d"]  = int(p.get("n_d",  1))
                blk["n_i"]  = int(p.get("n_i",  0))
                blk["n_oa"] = int(p.get("n_oa", 1))
                blk["n_od"] = int(p.get("n_od", 1))
                blk["n_oi"] = int(p.get("n_oi", 0))
                for i in range(1, int(p.get("n_a", 0)) + 1):
                    isb, src_port = wire_src(bid, f"A{i}")
                    ref = signal_ref(isb)
                    # FIX inter-pages : PYBLOCK.OA{N} transmis via PAGE_OUT→PAGE_IN
                    # signal_ref ne connaît que OA1, cette passe couvre OA2+
                    if ref is None and isb and isb.get("type") == "PYBLOCK" and src_port:
                        sp = src_port.upper()
                        if sp.startswith("OA"):
                            ref = isb.get("params", {}).get(f"oa{sp[2:]}_ref")
                    blk[f"a{i}_ref"] = ref if ref is not None else p.get(f"a{i}_ref", f"RF{i-1}")
                # FIX: bool_ref_for_input gère OR/INV/XOR/AND/COIL/Timer → bit M temp
                _pre_coils_py = []
                for i in range(1, int(p.get("n_d", 0)) + 1):
                    isb, src_port = wire_src(bid, f"d{i}")
                    ref = bool_ref_for_input(isb, src_port, _pre_coils_py)
                    blk[f"d{i}_ref"] = ref if ref is not None else p.get(f"d{i}_ref")
                prog.extend(_pre_coils_py)   # COIL implicites AVANT le PYBLOCK
                for i in range(1, int(p.get("n_i", 0)) + 1):
                    isb, _ = wire_src(bid, f"I{i}")
                    ref = signal_ref(isb)
                    blk[f"i{i}_ref"] = ref if ref is not None else p.get(f"i{i}_ref", f"RF{12+i}")
                for i in range(1, int(p.get("n_oa", 0)) + 1):
                    ref = resolve_reg_out(bid, f"OA{i}")
                    blk[f"oa{i}_ref"] = ref if ref is not None else p.get(f"oa{i}_ref", f"RF{i-1}")
                for i in range(1, int(p.get("n_od", 0)) + 1):
                    canvas_rf = p.get(f"od{i}_ref")
                    if canvas_rf and isinstance(canvas_rf, str) and canvas_rf.startswith("RF"):
                        # RF canvas déjà assigné → utiliser directement
                        blk[f"od{i}_ref"] = canvas_rf
                    else:
                        ref = resolve_bool_out(bid, f"od{i}")
                        # FIX: si resolve retourne GPIO int mais canvas a RF -> garder les deux
                        if isinstance(ref, int) and canvas_rf and str(canvas_rf).startswith("RF"):
                            blk[f"od{i}_ref"]  = canvas_rf
                            blk[f"od{i}_gpio"] = ref
                        else:
                            blk[f"od{i}_ref"] = ref if ref is not None else canvas_rf
                if p.get("n_oi", 0) > 0:
                    blk["oi1_ref"] = resolve_reg_out(bid, "OI1") or "RF15"
                prog.append(blk)


        # ════════════════════════════════════════════════════════════════════
        # ── PASS 2 : OUTPUT blocks driven directly by INPUT / logic blocks ──
        # Blocs OUTPUT câblés directement depuis INPUT, AND, OR, NOT, XOR, INV,
        # DV (multi-sorties) — ils ne génèrent aucun engine-block dans le pass 1
        # (tous dans la liste skip). On génère ici des coils implicites.
        # ════════════════════════════════════════════════════════════════════
        def resolve_all_bool_outs(src_bid, port="OUT"):
            """Retourne TOUTES les destinations booléennes câblées sur un port."""
            outs = []
            for w in wires:
                if w["src"]["bid"] == src_bid and w["src"]["port"] == port:
                    db = blocks.get(w["dst"]["bid"])
                    if db:
                        t = db["type"]; pp = db.get("params", {})
                        if t == "OUTPUT": outs.append(int(pp.get("pin", 17)))
                        elif t == "MEM":  outs.append(pp.get("bit", "M0"))
                        elif t == "DV":   outs.append(pp.get("varname", "dv0"))
            return outs

        LOGIC_BLOCKS = {"AND", "OR", "NOT", "XOR", "INV", "NAND", "NOR",
                        "SR_R", "SR_S", "COIL", "SET", "RESET",
                        "TON", "TOF", "TP", "WAIT", "WAITH", "PULSE",
                        "CTU", "CTD", "CTUD",
                        "COMPARE_F", "COMPH", "COMPL", "HYST"}

        generated_outputs = set()
        for blk in prog:
            if "output" in blk:
                generated_outputs.add(blk["output"])

        for b in sorted_b:
            bid = b["id"]; bt = b["type"]; p = b.get("params", {})

            if bt == "OUTPUT":
                gpio_pin = int(p.get("pin", 17))
                if gpio_pin in generated_outputs:
                    continue
                src_b, src_port_out = wire_src(bid, "VAL")
                if src_b is None:
                    continue
                st = src_b["type"]
                cond = None
                if st == "INPUT":
                    cond = {"type": "input", "ref": int(src_b.get("params", {}).get("pin", 22))}
                elif st in LOGIC_BLOCKS:
                    cond = build_cond(src_b)
                elif st == "DV":
                    sp = src_b.get("params", {})
                    cond = {"type": "input", "ref": sp.get("varname", "dv0")}
                elif st == "MEM":
                    cond = {"type": "input", "ref": src_b.get("params", {}).get("bit", "M0")}
                elif st in ("PYBLOCK", "CARITHM"):
                    # FIX : PYBLOCK.od{N} → OUTPUT : lire od{N}_ref (registre RF écrit par le pyblock)
                    _sp = (src_port_out or "").lower()
                    _od_ref = src_b.get("params", {}).get(f"{_sp}_ref")
                    if _od_ref:
                        cond = {"type": "input", "ref": _od_ref}
                if cond:
                    prog.append({"id": f"__auto_coil_{bid}",
                                 "type": "coil",
                                 "condition": cond,
                                 "output": gpio_pin})
                    generated_outputs.add(gpio_pin)

            elif bt == "DV":
                varname = p.get("varname", "dv0").lower()  # normalise casse
                all_outs = resolve_all_bool_outs(bid, "OUT")
                for o in all_outs:
                    if o not in generated_outputs:
                        prog.append({"id": f"__auto_dv_{bid}_{o}",
                                     "type": "coil",
                                     "condition": {"type": "input", "ref": varname},
                                     "output": o})
                        generated_outputs.add(o)

            elif bt == "INPUT":
                gpio_in = int(p.get("pin", 22))
                all_outs = resolve_all_bool_outs(bid, "VAL")
                for o in all_outs:
                    if o not in generated_outputs:
                        prog.append({"id": f"__auto_input_{bid}_{o}",
                                     "type": "coil",
                                     "condition": {"type": "input", "ref": gpio_in},
                                     "output": o})
                        generated_outputs.add(o)

        # Exposer la carte block_id → M-bit temporaire pour le canvas
        # Ex: {"or1": "M24", "inv1": "M25"} utilisé pour colorer les fils
        mbit_map = {}
        for (bid, port), mbit in _tmp_m_used.items():
            if not str(bid).startswith("__tmp"):
                mbit_map[bid] = mbit
        self._logic_mbit_map = mbit_map

        return prog

    # ── Programme linéaire → diagramme FBD (pour chargement depuis fichier) ──
    def _program_to_fbd(self, prog: list) -> dict:
        fbd_blocks = []; fbd_wires = []
        x = 40; y = 40
        type_map = {
            "coil":"COIL","set":"SET","reset":"RESET",
            "timer":"TON","counter":"CTU","compare":"GT",
        }
        for i, b in enumerate(prog):
            bt  = type_map.get(b.get("type",""),"COIL")
            bid = b.get("id", f"B{i+1}")
            fb  = {"id":bid,"type":bt,"x":x+140,"y":y,"params":{}}
            if bt=="TON": fb["params"]["preset_ms"]=b.get("preset_ms",1000)
            if bt=="CTU": fb["params"]["preset"]=b.get("preset",10)
            fbd_blocks.append(fb)
            cond = b.get("condition")
            if cond and cond.get("type")=="input":
                ref = cond["ref"]
                in_bid = f"{bid}_IN"
                pt = "INPUT" if isinstance(ref,int) else "MEM"
                pp = {"pin":ref} if isinstance(ref,int) else {"bit":ref}
                fbd_blocks.append({"id":in_bid,"type":pt,"x":x-40,"y":y,"params":pp})
                ep = {"COIL":"EN","SET":"S","RESET":"R","TON":"IN","CTU":"CU"}.get(bt,"EN")
                fbd_wires.append({"id":f"W{i}i","src":{"bid":in_bid,"port":"VAL"},"dst":{"bid":bid,"port":ep}})
            out = b.get("output")
            if out is not None:
                out_bid = f"{bid}_OUT"
                ot = "OUTPUT" if isinstance(out,int) else "MEM"
                op = {"pin":out} if isinstance(out,int) else {"bit":out}
                fbd_blocks.append({"id":out_bid,"type":ot,"x":x+320,"y":y,"params":op})
                qp = {"COIL":"Q","SET":"Q","RESET":"Q","TON":"Q","CTU":"Q"}.get(bt,"Q")
                fbd_wires.append({"id":f"W{i}o","src":{"bid":bid,"port":qp},"dst":{"bid":out_bid,"port":"VAL"}})
            y += 130
        return {"pages":[{"id":"P1","name":"Page 1","blocks":fbd_blocks,"wires":fbd_wires}],"curPage":0}

    # ── API publique ──────────────────────────────────────────────────────────
    def get_program(self):
        """Retourne le diagramme FBD complet (dict multi-pages) pour sauvegarde."""
        return self._diagram if self._diagram.get("pages") else self._fbd_to_program(self._diagram)

    def sync_and_save(self, callback):
        """Demande le diagramme courant au JS puis appelle callback(diagram).
        Utilisé par la sauvegarde pour garantir que _diagram est à jour."""
        if not HAS_WEBENGINE:
            callback(self._diagram)
            return
        def _on_result(result):
            if result and isinstance(result, dict) and result.get("pages"):
                self._diagram = result
            callback(self._diagram)
        self.view.page().runJavaScript(
            "window.fbdAPI ? JSON.parse(JSON.stringify(window.fbdAPI.getDiagram())) : null",
            _on_result
        )

    def get_engine_program(self) -> list:
        """Retourne la liste plate de blocs pour le moteur PLC."""
        return self._fbd_to_program(self._diagram)

    def load_program(self, data):
        """Charge un programme/diagramme dans le canvas FBD."""
        if not HAS_WEBENGINE:
            return
        if getattr(self, '_canvas_ready', False):
            # Canvas prêt — petit délai pour laisser tout JS en cours se terminer
            # avant d'envoyer le nouveau diagramme (évite race condition)
            from PyQt5.QtCore import QTimer
            QTimer.singleShot(50, lambda: self._do_load(data))
        else:
            # Canvas pas encore prêt → mettre en attente
            self._pending_load = data

    def import_blocks(self, data):
        """Importe les blocs d'un exemple dans la page courante (sans remplacer le projet)."""
        if not HAS_WEBENGINE:
            return
        import json as _j
        if not getattr(self, '_canvas_ready', False):
            return  # canvas pas prêt, ignorer
        self.view.page().runJavaScript(
            f"window.fbdAPI && window.fbdAPI.importBlocks({_j.dumps(data)})"
        )

    def update_from_state(self, state: dict):
        if not HAS_WEBENGINE: return
        # Injecter la carte bit-M temporaires pour que le canvas puisse
        # colorer correctement les fils issus des blocs logiques (OR, INV, XOR…).
        # Ex: {"or1": "M24", "inv1": "M25"} → canvas lit memory["M24"] pour OR.active
        mbit_map = getattr(self, '_logic_mbit_map', {})
        if mbit_map:
            state = dict(state)
            state['logic_mbits'] = mbit_map
        self.bridge.set_pending_state(json.dumps(state))
        self.view.page().runJavaScript(
            "if(window.pybridge&&window.pybridge.get_pending_state){"
            "  window.pybridge.get_pending_state(function(s){"
            "    if(!s)return;"
            "    try{var d=JSON.parse(s);"
            "      window.fbdAPI&&window.fbdAPI.updateActiveStates(d);"
            "      try{_trendUpdate(d);}catch(e){}"
            "    }catch(e){}"
            "  });"
            "}"
        )


    def clear(self):
        self._diagram = {"blocks":[],"wires":[]}
        if HAS_WEBENGINE:
            self.view.page().runJavaScript("window.fbdAPI && window.fbdAPI.clearAll()")
        self.program_changed.emit([])

    def fit_view(self):
        if HAS_WEBENGINE:
            self.view.page().runJavaScript("window.fbdAPI && window.fbdAPI.fitView()")

    def set_analog_config(self, analog_config: dict):
        """Pousse la config sondes (Ctrl+T) dans le canvas FBD (enrichit les dropdowns ANA0…ANA11)."""
        self._pending_analog_config = analog_config  # cache pour re-push après loadFinished
        if HAS_WEBENGINE and self._canvas_ready:
            import json as _json
            cfg_js = _json.dumps(analog_config)
            self.view.page().runJavaScript(
                f"window.setAnalogConfig && window.setAnalogConfig({cfg_js});"
            )

